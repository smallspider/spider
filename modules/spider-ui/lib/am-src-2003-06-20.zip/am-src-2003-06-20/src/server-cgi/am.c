/*
 *	am.c
 *
 *	cgi for a web server to serve AM applets
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
 
/*
 */ 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h> // for sleep function
#include "am_msg_file.h"

#ifdef __cplusplus__
extern "C" {
#endif

#ifndef MESSAGE_PATH
#define MESSAGE_PATH "messages"
#endif

////////////////////////////// HTTP functions ///////////////////////////////

void printStatusLine(int statusCode, char* string) {
	printf("Status: %d %s\r\n", statusCode, string);
}

void printTextContentType() {
  printf("Content-type: text/plain\r\n");
}

void printHtmlContentType() {
  printf("Content-type: text/html\r\n");
}

void printAudioContentType() {
  printf("Content-type: audio/basic\r\n");
}

////////////////////////////// Utility functions //////////////////////////

void cgiExit(int code) {
	exit(code);
}

void cgiError(int statusCode, char* format, ...) {
	char string[500];
	va_list ap;
	va_start(ap, format);
	vsprintf(string, format, ap);
	va_end(ap);
	printStatusLine(statusCode, string);
	printTextContentType();
	printf("\r\n");
	printf("Error %d:\r\n", statusCode);
	printf("%s\r\n", string);
	cgiExit(1);
}

char* getEnvString(char* name, int mandatory) {
	char* result = getenv(name);
	if ((!result || result[0]==0)) {
		if (mandatory) {
			cgiError(500, "Internal error: \"%s\" is not in CGI environment.", name);
		}
		result=NULL;
	}
#ifdef TRACE
	fprintf(stderr, "Env \"%s\"=\"%s\"\n", name, result);
#endif
	return result;
}

int getAMMessage(char* dir, struct dirent* currdir, AMMessage* msg) {
	if (currdir->d_name==NULL
	    || currdir->d_name[0]=='.') {
			return 0;
	}
	return readMsgHeaderDir(dir, currdir->d_name, msg);
}

int fileExists(char* filename) {
	// todo: better method !
	struct stat fileInfo;
	return !stat(filename, &fileInfo);
}

char* getPutFilename() {
	static int number=1;
	static char ret[400];
	char* zeros;
	
	do {
		if (number>999) {
			zeros="";
		} else if (number>99) {
			zeros="0";
		} else if (number>9) {
			zeros="00";
		} else {
			zeros="000";
		}
		sprintf(ret, "%s/%s%d%s", MESSAGE_PATH, zeros, number, FILENAME_TRAILER);
		number++;
	} while (fileExists(ret));
	return ret;
}

char* getFilenameById(char* id) {
	char* result;
	DIR* dirp;
	struct dirent* currdir;
	AMMessage msg;
	
#ifdef DEBUG
	fprintf(stderr, "Trying to find message with id \"%s\".\n", id);
#endif
	result=NULL;
	dirp=opendir(MESSAGE_PATH);
	if (!dirp) {
		cgiError(500, "Cannot access the message directory !");
	}
	while ((currdir=readdir(dirp))) {
		if (getAMMessage(MESSAGE_PATH, currdir, &msg)) {
			if (strcmp(id, msg.id)==0) {
				// message found
				result=getMsgFilename(MESSAGE_PATH, currdir->d_name);
				break;
			}
		}
	}
	closedir(dirp);
	if (!result) {
		cgiError(404, "Could not find message id \"%s\".", id);
	}
	return result;
}
	

////////////////////////////// command functions /////////////////////////////////

/*
 * Sends the list of messages to client.
 * Format:
 * <id> <size> <date> <formatCode> <description text>\n
 */
void sendList() {
	DIR* dirp;
	struct dirent* currdir;
	AMMessage msg;

	dirp=opendir(MESSAGE_PATH);
	if (!dirp) {
		cgiError(500, "Cannot access the message directory !");
	}
	printStatusLine(200, "OK");
	printTextContentType();
	printf("\r\n");
	while ((currdir=readdir(dirp))) {
		if (getAMMessage(MESSAGE_PATH, currdir, &msg)) {
			// msg.date is in seconds since the epoch
			printf("%s %lu %lu000 %d %s\n", msg.id, msg.size, msg.date, msg.format, msg.desc);
		}
	}
	closedir(dirp);
	printf("\n");
}

/*
 * Sends the requested file.
 * One or 2 params:
 * 1. <id> of file to retrieve
 * 2. <offset> start position of the file to send in bytes (optional)
 *
 */
void getFile(char* params[], int paramCount) {
	int offset=0;
	int read;
	int processedChunks;
	char* filename;
	char buffer[4096];
	FILE* file;
	
	if (paramCount<1) {
		cgiError(400, "No file id specified !");
	}
	if (paramCount>1) {
		offset=atoi(params[1]);
	}
	filename=getFilenameById(params[0]);

#ifdef DEBUG
	fprintf(stderr, "Sending message \"%s\" at offset %d.\n", filename, offset);
#endif
	
	file=fopen(filename, "rb");
	if (!file) {
		cgiError(500, "Could not open file \"%s\".", filename);
	}
	printStatusLine(200, "OK");
	printAudioContentType();
	printf("\r\n");
	fseek(file, offset, SEEK_SET);
	processedChunks=0;
	fflush(stdout);
	while ((read=fread(buffer, 1, sizeof(buffer), file))) {
		fwrite(buffer, 1, read, stdout);
		fflush(stdout);
		processedChunks++;
#ifdef SLOW_SERVER	
		if ((processedChunks % 15) == 0) sleep(1);
#endif
#ifdef TRACE
		if ((processedChunks % 15) == 0)
			fprintf(stderr, "Sent %d chunks\n", processedChunks);
#endif
	}
	fclose(file);
}

void doPutFile(char* filename, int maxLen) {
	char buffer[4096];
	FILE* file;
	int read;
	int processedChunks;
	int totalRead=0;

#ifdef DEBUG
	fprintf(stderr, "Writing file %s.", filename);
#endif
	file=fopen(filename, "wb");
	if (!file) {
		cgiError(404, "Error creating file \"%s\".", filename);
	}
	printStatusLine(200, "OK");
	printTextContentType();
	printf("\r\n");
	fflush(stdout);
	processedChunks=0;
	do {
		read=sizeof(buffer);
		if (maxLen>0 && (totalRead+read)>maxLen) {
			read=maxLen-totalRead;
			if (read<=0) {
				break;
			}
		}
		read=fread(buffer, 1, read, stdin);
		if (read>0) {
			fwrite(buffer, 1, read, file);
			processedChunks++;
			totalRead+=read;
#ifdef SLOW_SERVER
			if ((processedChunks % 15) == 0) sleep(1);
#endif
#ifdef TRACE
			if ((processedChunks % 15) == 0)
				fprintf(stderr, "Received %d chunks\n", processedChunks);
#endif
		}
	} while (read>0);
	fclose(file);
#ifdef DEBUG
	fprintf(stderr, "Wrote %d bytes into %s.", totalRead, filename);
#endif
}

void putFile() {
	char* sMaxLen;
	int maxLen=-1;

	sMaxLen=getEnvString("CONTENT_LENGTH", 0);
	if (sMaxLen) {
		maxLen=atoi(sMaxLen);
		if (maxLen==0) {
			maxLen=-1;
		}
	}
	doPutFile(getPutFilename(), maxLen);
}

/*
 * Sends the requested file.
 * One or 2 params:
 * 1. <id> of file to retrieve
 * 2. <offset> start position of the file to send in bytes (optional)
 *
 */
void removeFile(char* params[], int paramCount) {
	char* filename;
	
	if (paramCount<1) {
		cgiError(400, "No file id specified !");
	}
	filename=getFilenameById(params[0]);

#ifdef DEBUG
	fprintf(stderr, "Deleting message \"%s\".\n", filename);
#endif
	if (unlink(filename)) {
		cgiError(500, "Could not remove file \"%s\".", filename);
	}		
	printStatusLine(200, "OK");
	printTextContentType();
	printf("\r\n");
}
////////////////////////////// command parsing /////////////////////////////////

/*
 * Read command and its parameters.
 * Parameters:
 * OUT    command   : string where to pplace the command string
 * IN     maxCmdLen : max number of chars in command
 */
void readCommand(char* command, int maxCmdLen) {
	char* method;
	
	method = getEnvString("REQUEST_METHOD", 1);
	strncpy(command, method, maxCmdLen);
	// terminate it
	command[maxCmdLen]=0;
}

/*
 * Read parameters.
 * Parameters:
 * OUT    param        : array of parameters. param[0]=first parameter, etc.
 * IN     maxParamCount: max number of parameters
 * IN     paramLen     : max number opf characters for each parameter
 * Returns the number of parameters
 */
int readParams(char* params[], int maxParamCount, int paramLen) {
	char* query;
	int paramCount=0;
	char* nextParam;
	unsigned int thisParamLen;
	
	query = getEnvString("QUERY_STRING", 0);
	if (query!=NULL) {
		paramCount=0;
		while ((paramCount<(maxParamCount-1)) && (nextParam=strchr(query, '&'))!=NULL) {
			thisParamLen=(unsigned int) (nextParam-query);
			if (thisParamLen>paramLen) {
				thisParamLen=paramLen;
			}
			if (thisParamLen>0) {
				strncpy(params[paramCount], query, thisParamLen);
			}
			// terminate it
			params[paramCount][thisParamLen]=0;
			// move to next parameter
			query=(nextParam+1);
			paramCount++;
		}
		// treat last parameter.
		thisParamLen=strlen(query);
		if (thisParamLen>0) {
			strncpy(params[paramCount], query, thisParamLen);
		}
		// terminate it
		params[paramCount][thisParamLen]=0;
		paramCount++;
	}
	return paramCount;
}

#ifdef COMMAND_LINE
int readParametersFromCommandLine(int argc, char* argv[], char* params[], int maxParamCount, int paramLen) {
	int paramCount;
	for (paramCount=0; (paramCount+2)<argc && paramCount<maxParamCount; paramCount++) {
		strncpy(params[paramCount], argv[paramCount+2], paramLen);
	}
	return paramCount;
}
#endif

void execCommand(char* command, char* params[], int paramCount) {
#ifdef DEBUG
	int i;
	fprintf(stderr, "Executing: %s", command);
	for (i=0; i<paramCount; i++) {
		fprintf(stderr, " %s", params[i]);
	}
	fprintf(stderr, "\n");
#endif
	
	if (strcmp(command, "list")==0 || strcmp(command, "LIST")==0) {
		sendList();
	}
	else if (strcmp(command, "get")==0 || strcmp(command, "GET")==0) {
		getFile(params, paramCount);
	}
	else if (strcmp(command, "put")==0 || strcmp(command, "PUT")==0) {
		putFile();
	}
	else if (strcmp(command, "remove")==0 || strcmp(command, "REMOVE")==0) {
		removeFile(params, paramCount);
	} else {
		// bad...
		if (paramCount<=0) {
			cgiError(501, "Unsupported command: %s", command);
		} else if (paramCount==1) {
			cgiError(501, "Unsupported command: %s %s", command, params[0]);
		} else {
			cgiError(501, "Unsupported command: %s %s %s", command, params[0], params[1]);
		}
	}
}

////////////////////////////// main /////////////////////////////////

#define MAX_COMMAND_LEN 10
#define MAX_PARAM_LEN 100
#define MAX_PARAM_COUNT 10

int main (int argc, char *argv[]) {
	char command[MAX_COMMAND_LEN+1];     // command the client sent
	char paramArray[MAX_PARAM_COUNT][MAX_PARAM_LEN+1];
	char* params[MAX_PARAM_COUNT]; // parameters for command
	int paramCount;

	// hmmm
	for (paramCount=0; paramCount<MAX_PARAM_COUNT; paramCount++) {
		params[paramCount]=paramArray[paramCount];
	}

#ifdef COMMAND_LINE
	if (argc>1) {
		strncpy(command, argv[1], MAX_COMMAND_LEN);
		command[MAX_COMMAND_LEN]=0;
	} else
#endif
	readCommand(command, MAX_COMMAND_LEN);
#ifdef COMMAND_LINE
	if (argc>1) {
		paramCount=readParametersFromCommandLine(argc, argv, params, MAX_PARAM_COUNT, MAX_PARAM_LEN);
	} else
#endif
	paramCount=readParams(params, MAX_PARAM_COUNT, MAX_PARAM_LEN);
	execCommand(command, params, paramCount);
	cgiExit(0);
	return 0;
}

#ifdef __cplusplus__
}
#endif
