/*
 *	am_msg_file.c
 *
 *	AMMessage file header reader functions
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
#include "am_msg_file.h"

int big2littleEndian(int big) {
	return ((big & 0xFF)<<24)
		 | ((big & 0xFF00) << 8) 
		 | ((big & 0xFF0000) >> 8) 
		 | (big >> 24);
}

char globalFilePath[400];

char* getMsgFilename(const char* dir, const char* filename) {
	if (strlen(dir)+strlen(filename)+2>sizeof(globalFilePath)) {
		return NULL;
	}
	sprintf(globalFilePath, "%s/%s", dir, filename);
	return globalFilePath;
}
	

int readMsgHeaderDir(const char* dir, const char* filename, AMMessage* msg) {
	return readMsgHeader(getMsgFilename(dir, filename), msg);
}


int readMsgHeader(const char* filename, AMMessage* msg) {
	struct stat fileInfo;
	FILE* file;
	int i, len;
	
	if (filename==NULL) {
		return 0;
	}
	if (strlen(filename)<strlen(FILENAME_TRAILER)
	    || strcmp(filename+strlen(filename)-strlen(FILENAME_TRAILER), FILENAME_TRAILER)!=0) {
#ifdef DEBUG
			fprintf(stderr, "Ignoring file \"%s\".\n", filename);
#endif
	    	return 0;
	}
	if (stat(filename, &fileInfo)) {
#ifdef DEBUG
		fprintf(stderr, "Could not get stat for file \"%s\".\n", filename);
#endif			    	
		return 0;
	}
	msg->size=fileInfo.st_size;
	msg->date=fileInfo.st_mtime;
	// read file header
	file=fopen(filename, "rb");
	if (!file) {
#ifdef DEBUG
		fprintf(stderr, "Could not open file \"%s\".\n", filename);
#endif			    	
		return 0;
	}
	// magic
	if (fread(&i, 4, 1, file)!=1 || i!=big2littleEndian(HEADER_MAGIC)) {
#ifdef DEBUG
		fprintf(stderr, "File \"%s\" has wrong header magic.\n", filename);
#endif			    	
		fclose(file);
		return 0;
	}
	if (fread(&i, 4, 1, file)!=1) {
#ifdef DEBUG
		fprintf(stderr, "Could not read format code in file \"%s\".\n", filename);
#endif			    	
		fclose(file);
		return 0;
	}
	msg->format=big2littleEndian(i);
	// read description len
	if (fread(&i, 4, 1, file)!=1) {
#ifdef DEBUG
		fprintf(stderr, "Could not read descr len in file \"%s\".\n", filename);
#endif			    	
		fclose(file);
		return 0;
	}
	len=big2littleEndian(i);
	if (len<0 || len>MAX_DESCRIPTION_LENGTH) {
#ifdef DEBUG
		fprintf(stderr, "Could not descr len (%d) invalid in file \"%s\".\n", len, filename);
#endif			    	
		fclose(file);
		return 0;
	}
	if (len>0) {
		if (fread(msg->desc, len, 1, file)!=1) {
#ifdef DEBUG
			fprintf(stderr, "Could not read descr in file \"%s\".\n", filename);
#endif			    	
			fclose(file);
			return 0;
		}
	} else {
		strcpy(msg->desc, "(anonymous)");
	}
	fclose(file);
	// now set id
	sprintf(msg->id, "%lx%lx", msg->size, msg->date & 0xFFFFFF);
	return 1;
}

