/*
 *	am_msg_file.h
 *
 *	header for AMMessage file header reader
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
 
#ifndef AM_MSG_FILE_INCLUDED
#define AM_MSG_FILE_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include <dirent.h>

#define FILENAME_TRAILER "_message.am"
#define HEADER_MAGIC 0x464D3031 /* "FM01" */
#define MAX_DESCRIPTION_LENGTH 400
#define MAX_ID_LENGTH 20

typedef struct tag_AMMessage {
	char          id[MAX_ID_LENGTH];
	unsigned long size;
	time_t        date;
	int           format;
	char          desc[MAX_DESCRIPTION_LENGTH+1];
} AMMessage;

#ifdef __cplusplus__
extern "C" {
#endif

extern char* getMsgFilename(const char* dir, const char* filename);
extern int readMsgHeaderDir(const char* dir, const char* filename, AMMessage* msg);
extern int readMsgHeader(const char* filename, AMMessage* msg);

#ifdef __cplusplus__
}
#endif

#endif