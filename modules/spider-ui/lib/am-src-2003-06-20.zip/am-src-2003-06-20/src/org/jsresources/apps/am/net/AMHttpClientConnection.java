/*
 *	AMHttpClientConnection.java
 *
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package org.jsresources.apps.am.net;

import	org.jsresources.apps.am.Debug;
import	java.io.IOException;
import	java.io.InputStream;
import	java.io.OutputStream;
import	java.io.DataOutputStream;
import	java.net.Socket;
import	java.net.SocketException;
import	java.net.URL;
import	java.util.StringTokenizer;
import	java.util.NoSuchElementException;

/**
 * A self-written HTTP client to avoid buffering done by Java's
 * URLConnection. It communicates with an http server.
 */

public class AMHttpClientConnection extends ClientConnection implements NetConstants {

	private byte[] m_buffer=null;
	private Socket m_socket;
	
	/*
	 * As the HTTP/1.0 (RFC 1945) protocol defines that we must set the 
	 * content length, (what we cannot do for the PUT command), we just 
	 * set it to a maximum size that should be sufficient for all purposes.
	 * The end of stream is denoted by closing the network connection.
	 * This works fine with Apache, don't know for other servers.
	 */
	private final long MAX_CONTENT_LEN=1000000; // 1 MB as maximum

	AMHttpClientConnection(URL url) {
		super(url);
	}

	protected void sendRequest(String command, String params) throws IOException {
		URL url=getHttpURL(params);
		// get host name
		String host=url.getHost();
		// get port
		int port=url.getPort();
		if (port<0) {
			port=80; // http default port
		}
		// get protocol
		String proto=url.getProtocol();
		if (proto==null || proto=="") {
			proto="http";
		}
		// get path
		String path=url.getPath();
		if (path==null || path=="") {
			path="/";
		}
		// get query and add it to path
		String query=url.getQuery();
		if (query!=null && query!="") {
			path+="?"+query;
		}
		if (host==null || host=="" || !proto.equalsIgnoreCase("http")) {
			throw new IOException("URL "+url+" is not suitable for http protocol!");
		}
		m_socket=new Socket(host, port);
		m_socket.setSoTimeout(NET_TIMEOUT);
		m_inStream=m_socket.getInputStream();
		m_outStream=m_socket.getOutputStream();
		DataOutputStream dataOutStream=new DataOutputStream(m_outStream);

		// write http request
		dataOutStream.writeBytes(command+" "+path+" HTTP/1.0\r\n");
		
		dataOutStream.writeBytes("User-Agent: "+USER_AGENT+"\r\n");
		// support virtual servers
		if (!Character.isDigit(host.charAt(host.length()-1))) {
			dataOutStream.writeBytes("Host: "+host+"\r\n");
		}
		// if no output is wished, we can safely set content length
		if (!m_doOutput) {
			dataOutStream.writeBytes("Content-length: 0\r\n");
		} else {
			dataOutStream.writeBytes("Content-type: audio/basic\r\n");
			dataOutStream.writeBytes("Content-length: "+MAX_CONTENT_LEN+"\r\n");
		}
		// enough headers, folks !
		dataOutStream.writeBytes("\r\n");
		dataOutStream.flush();
		if (!m_doOutput) {
			m_outStream=null;
		} else {
			m_outStream=new LengthLimitedOutputStream(m_outStream, MAX_CONTENT_LEN);
		}
	}

	// reads a line terminated with "\n" or "\r\n"
	// buggy: should use a PushbackInputStream instead
	private String readLine() throws IOException {
		if (m_buffer==null) {
			m_buffer=new byte[400];
		}
		String res="";
		do {
			for (int i=0; i<m_buffer.length; i++) {
				int r;
				do {
					r=m_inStream.read(m_buffer, i, 1);
					if (r<0) {
						throw new IOException("Premature end of Server headers");
					}
				} while (r==0);
				if (m_buffer[i]=='\n' || m_buffer[i]=='\r') {
					// end of line
					if (m_buffer[i]=='\r') {
						// expect an "\n" after \r
						m_inStream.read();
					}
					m_buffer[i]=0;
					if (i>0) {
						res+=new String(m_buffer, 0, i);
					}
					if (Debug.TRACE_READWRITE) {
						Debug.println("From Server: "+res);
					}
					return res;
				}
			}
			res+=new String(m_buffer);
		} while (true);
	}

	private void readResponse() throws IOException {
		// don't use readers. They do not guarantee that not more
		// characters are read from the stream
		//BufferedReader br=new BufferedReader(new InputStreamReader(m_inputStream));
		
		// status line
 		String line=readLine();
		if (Debug.TRACE && !Debug.TRACE_READWRITE) {
			Debug.println("Server responded with "+line);
		}
		StringTokenizer	tokenizer = new StringTokenizer(line);
		try {
			if (!tokenizer.nextToken().startsWith("HTTP/1.")) {
 				throw new IOException("Server did not respond with HTTP/1. !");
 			}
			String status=tokenizer.nextToken();
			// rest is status message
			String msg="";
			while (tokenizer.hasMoreTokens()) {
				msg+=" "+tokenizer.nextToken();
			}
			if (!"200".equals(status)) {
 				throw new IOException("Server problem: "+status+" "+msg);
 			}
		} catch (NoSuchElementException nse) {
			throw new IOException("No status from server !");
		}
		// ignore the rest of the headers
		while (readLine()!="");
	}

	public void sendCommandImpl(String command, String params) throws IOException {
		close();
		sendRequest(command, params);
		if (!m_doOutput) {
			readResponse();
		}
	}

	public int getSendBufferSize() {
		try {
			if (m_socket!=null) {
				return m_socket.getSendBufferSize();
			}
		} catch (SocketException se) {}
		return super.getSendBufferSize();
	}
	
	class LengthLimitedOutputStream extends OutputStream {
		private long length;
		private long pos;
		private OutputStream stream;
		
		public LengthLimitedOutputStream(OutputStream stream, long length) {
			this.stream=stream;
			this.length=length;
		}
		
		public void write(int b) throws IOException {
			if (pos>=length) {
				if (pos==length) {
					close();
				}
				throw new IOException("Stream closed");
			}
			stream.write(b);
			pos++;
		}
		
		public void write(byte[] b) throws IOException {
			write(b, 0, b.length);
		}
		
		public void write(byte[] b, int off, int len) throws IOException {
			if (pos>=length) {
				if (pos==length) {
					close();
				}
				throw new IOException("Stream closed");
			}
			if (len+pos>=length) {
				len=(int) (length-pos);
			}
			stream.write(b, off, len);
			pos+=len;
		}
		
		public void flush() throws IOException {
			stream.flush();
		}
		
		public void close() throws IOException {
			pos=length+1;
			stream.close();
		}
	}
}

/*** AMHttpClientConnection.java ***/
