/*
 *	Synchronizer.java
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package org.jsresources.apps.am.audio;

import	org.jsresources.apps.am.Debug;

import	java.io.InputStream;
import	java.io.OutputStream;
import	java.io.IOException;

public class Synchronizer extends Thread {

	private InputStream m_inStream=null;
	private InputStream m_nextInStream=null;
	private OutputStream m_outStream=null;

	private byte[] buffer=null;
	private boolean running=false;
	private boolean stopping=false;
	private boolean smoothStop=false;
	private boolean streamsClosed=false;
	private long m_bytesWritten;
	private long m_bytesRead;
	private long m_startTime;
	//private boolean m_onlyReadWhenAvailable=true;
	private boolean m_onlyReadWhenAvailable=false;

	public Synchronizer(InputStream inStream, OutputStream outStream, int bufferSize) {
		super();
		if (Debug.TRACE) {
			Debug.println("Synchronizer <init> bufferSize="+bufferSize+" bytes.");
		}
		m_inStream=inStream;
		m_outStream=outStream;
		buffer= new byte[bufferSize];
		m_startTime=0;
	}

	public void setOnlyReadWhenAvailable(boolean value) {
		//m_onlyReadWhenAvailable=value;
	}

	// inStream and outStream must be ready for read/write operations
	public void start() {
		smoothStop=false;
		m_bytesRead=0;
		m_bytesWritten=0;
		m_startTime=System.currentTimeMillis();
		streamsClosed=false;
		super.start();
	}

	// immediately==
	//   true:  it is not waited that the thread finishes but all cuurent operations are aborted
	//   false: it is waited until the currently available data in InStream is read, written
	//          to OutStream and then that the thread has finished
	public void stop(boolean immediate) {
		if (Debug.TRACE_INOUT) {
			Debug.println("Synchronizer.stop("+immediate+") called.");
		}
		if (!immediate && currentThread()!=this && isRunning()) {
			// notify run() to stop after current buffer
			smoothStop=true;
			// wait for it to die
			try {
				if (Debug.DEBUG) {
					Debug.println("Synchronizer.stop(): waiting for thread to die");
				}
				join(2000); // run() will close the Streams by itself
			}
			catch (InterruptedException e) {}

			if (Debug.ERROR && isRunning()) {
				Debug.println("Synchronizer.stop(): join failed. Close socket.");
			}
		}
		closeStreams(immediate);
		if (Debug.TRACE_INOUT) {
			Debug.println("Synchronizer.stop("+immediate+") finish.");
		}
	}

	private void closeStreams(boolean immediate) {
		if (!streamsClosed) {
			if (m_inStream!=null) {
				try {
					if (Debug.TRACE) {
						Debug.println("Synchronizer.closeStreams("+immediate+"): closing inStream");
					}
					m_inStream.close();
				} catch (IOException ioe1) {}

			}
			if (m_outStream!=null) {
				try {
					if (Debug.TRACE) {
						Debug.println("Synchronizer.closeStreams("+immediate+"): closing outStream");
					}
					if (immediate) {
						m_outStream.flush();
					}
					m_outStream.close();
				} catch (IOException ioe2) {}

			}
			streamsClosed=true;
		}
	}

	public boolean isRunning() {
		return running;
	}

	public boolean isStopping() {
		return stopping;
	}

	public long getReadPos() {
		return m_bytesRead;
	}

	public long getWritePos() {
		return m_bytesWritten;
	}

	public long getTime() {
		if (m_startTime!=0) {
			return System.currentTimeMillis()-m_startTime;
		} else {
			return -1;
		}
	}

	public synchronized void setInputStream(InputStream in) {
		if (isRunning()) {
			m_nextInStream=in;
			try {
				m_outStream.flush();
				//m_inStream.close();
				notifyAll();
			} catch (IOException ie) {}

		} else {
			m_inStream=in;
		}
	}

	public void run() {
		int toReadBytes=buffer.length;
		int numBytesRead, available;
		running=true;
		stopping=false;
		try {
			while (true) {
				if (m_nextInStream!=null) {
					m_inStream=m_nextInStream;
					m_nextInStream=null;
				}
				if (streamsClosed) {
					if (Debug.DEBUG) {
						Debug.println("Synchronizer.run(): Streams are closed -> break");
					}
					break;
				}
				try {
					// hack for freezing system when TargetDataLine has availableRead<1
					available=m_inStream.available();
					if (!smoothStop && m_onlyReadWhenAvailable && available<(toReadBytes/2)) {
						//Debug.println("Synchronizer.run(): wait 5 ms.");
						synchronized (this) {
							try {
								wait(5);
							} catch (InterruptedException e) {}

						}
						continue;
					} else {
						if (smoothStop) {
							toReadBytes=available;
						}
						numBytesRead=m_inStream.read(buffer, 0, toReadBytes);
						//Debug.println("Synchronizer.run(): read "+numBytesRead+" bytes.");
					}

				} catch (IOException ioe1) {
					if (m_nextInStream!=null) {
						numBytesRead=0;
					} else {
						numBytesRead=-1;
					}
				}
				if (numBytesRead==-1 || streamsClosed) {
					if (Debug.DEBUG) {
						Debug.println("Synchronizer.run(): One or both streams are closed -> break");
					}
					break; // no need to keep on going when no input data anymore
				}

				if (numBytesRead>0) {
					m_bytesRead+=numBytesRead;
					try {
						m_outStream.write(buffer, 0, numBytesRead);
						m_bytesWritten+=numBytesRead;
					} catch (IOException ioe2) {
						if (Debug.DEBUG) {
							Debug.println("Synchronizer.run(): OutStream is closed -> break");
						}
						break; // no need to keep on going when no output data anymore
					}

				}
				if (smoothStop) {
					break;
				}
			}
		} catch (Throwable t) {
			if (Debug.ERROR) {
				Debug.println("Synchronizer.run():");
				Debug.println(t);
			}
		}
		m_startTime=0;
		stopping=true;
		// synchronized close of lines
		closeStreams(false);
		if (Debug.DEBUG) {
			Debug.println("Synchronizer.run(): smooth thread death");
		}
		running=false;
		stopping=false;
	}
}


/*** Synchronizer.java ***/

