/*
 *	Debug.java
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package org.jsresources.apps.am;

public class Debug {

	public static boolean ERROR=true;
	public static boolean DEBUG=true;
	public static boolean TRACE=false;
	public static boolean TRACE_READWRITE=false;
	public static boolean TRACE_INOUT=false;
	public static boolean SHOW_ALL_EXCEPTIONS=false;

	// for net.Server
	public static boolean SLOW_NET_UPLOAD=false;
	public static boolean SLOW_NET_DOWNLOAD=false;

	// show the time of a debug message
	private static final boolean SHOW_TIMES=false;
	private static long START_TIME=System.currentTimeMillis();

	public static synchronized void println(String sMessage) {
		if (SHOW_TIMES) {
			sMessage=""+(System.currentTimeMillis()-START_TIME)+": "+sMessage;
		}
		System.out.println(sMessage);
	}

	public static void println(Object obj, String sMessage) {
		String cn=obj.getClass().getName();
		int i=cn.lastIndexOf('.');
		if (i>=0 && i<cn.length()-1) {
			cn=cn.substring(i+1);
		}
		println(cn+": "+sMessage);
	}

	public static synchronized void println(Throwable t) {
		t.printStackTrace();
	}

	public static synchronized void printStackTrace() {
		Thread.dumpStack();
	}
}

/*** Debug.java ***/

