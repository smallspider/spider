/*
 *	Server.java
 */

/*
 *  Copyright (c) 2001 by Matthias Pfisterer <Matthias.Pfisterer@web.de>
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package org.jsresources.apps.am.net;

import	org.jsresources.apps.am.util.AMUtil;
import	org.jsresources.apps.am.audio.AMMsgFileTool;
import	org.jsresources.apps.am.Debug;

import	java.io.File;
import	java.io.FileInputStream;
import	java.io.FileOutputStream;
import	java.io.IOException;
import	java.io.InputStream;
import	java.io.OutputStream;
import	java.io.OutputStreamWriter;
import	java.io.Writer;

import	java.net.ServerSocket;
import	java.net.Socket;
import	java.net.SocketException;

import	java.util.ArrayList;
import	java.util.StringTokenizer;
import	java.util.List;


/**
   This is the standalone server process that allows the owner of the 
   answering machine to get a list of messages, download, upload and 
   delete them.
 
   The client program has to establish an ordinary socket connection 
   with AMClientConnection to this server. The protocol consists of four 
   actions that are triggered by the client programm. The client sends a 
   string with a command to the server. The server responds by sending 
   3 bytes "OK\n" or "Er\n". If it sent "OK\n", there may follow
   ASCII data, binary data or nothing at all, depending on the command. 
   The commands are described in ClientConnection.java.
   
   Note: in NetConstants, you set which server to use. There exist
   2 different client implementations for a HTTP server, and one which
   uses this server.
 */

public class Server
	extends Thread
	implements NetConstants {

	private static final String FILENAME_TRAILER="_message.am";
	private static final String MESSAGE_DIR=".";
	private static final File[]	EMPTY_FILE_ARRAY = new File[0];

	private static int	sm_nFilenameCounter = 0;

	private Socket		m_socket;
	private File[]		m_aMessageFiles;
	private int			m_id;
	private byte	aBytes[] = new byte[4096];



	/*	TODO: The thread should exit if the connection is closed.
	 */
	private Server(Socket socket, int id) {
		super();
		m_socket = socket;
		try {
			m_socket.setSoTimeout(60000); // timeout for the socket at 1 minute to prevent stale connections
		}
		catch (SocketException se) {}

		m_id=id;
	}

	private String getMessageID(long date, long filesize) {
		return String.valueOf(date ^ (filesize<<32));
	}

	private File getFile(StringTokenizer tokenizer) throws IndexOutOfBoundsException {
		File[]	aMessageFiles = getMessageFiles();
		if (aMessageFiles == null) {
			/*
			  there was no previous list, so do nothing.
			*/
			if (Debug.ERROR) {
				Debug.println("No previous list !");
			}
			throw new IndexOutOfBoundsException("");
		}
		String	ID = tokenizer.nextToken();
		for (int i=0; i<aMessageFiles.length; i++) {
			if (getMessageID(aMessageFiles[i].lastModified(), aMessageFiles[i].length()).equals(ID)) {
				return aMessageFiles[i];
			}
		}
		throw new IndexOutOfBoundsException("Server("+m_id+"): requested message with ID=" + ID + " does not exists !");
	}

	public void run() {
		try {
			InputStream		in = null;
			OutputStream		out = null;
			OutputStreamWriter	writer = null;
			in = m_socket.getInputStream();
			out = m_socket.getOutputStream();
			writer = new OutputStreamWriter(out);
			if (Debug.DEBUG) {
				Debug.println("Server("+m_id+"): spawned new server thread, now waiting for command");
			}
			while (true) {
				try {
					// read command, delimited by "\n"
					int len=0;
					int nRead=0;
					do {
						nRead = in.read();
						if (nRead<0) {
							throw new IOException("Server("+m_id+"): closed by other party.");
						}
						if (nRead!='\n') {
							aBytes[len++]=(byte) nRead;
						}
					} while (nRead!='\n');
					String	command = new String(aBytes, 0, len);

					writer.flush();
					out.flush();
					if (Debug.DEBUG) {
						Debug.println("Server("+m_id+"): got command: "+command);
					}
					StringTokenizer	tokenizer = new StringTokenizer(command);
					String	strCommand = tokenizer.nextToken();
					strCommand=strCommand.toUpperCase();
					if (strCommand.equals("LIST")) {
						writer.write("OK\n");
						writer.flush();
						sendList(writer);
					} else if (strCommand.equals("GET")) {
						File file=getFile(tokenizer);
						writer.write("OK\n");
						writer.flush();
						long offset=0;
						if (tokenizer.hasMoreTokens()) {
							offset=AMUtil.str2long(tokenizer.nextToken(), 0);
						}
						if (Debug.DEBUG) {
							Debug.println("Server("+m_id+"): serving "+file.getName()+" at offset "+offset+".");
						}
						FileInputStream	messageIn = new FileInputStream(file);
						if (offset>0) {
							messageIn.skip(offset);
						}
						try {
							while (true) {
								int	nBytesRead = messageIn.read(aBytes);
								if (nBytesRead == -1) {
									break;
								}
								if (Debug.SLOW_NET_DOWNLOAD) {
									try {
										sleep(50);
									} catch (InterruptedException ie) {}

								}
								out.write(aBytes, 0, nBytesRead);
							}
						}
						finally {
							messageIn.close();
						}
					} else if (strCommand.equals("PUT")) {
						writer.write("OK\n");
						writer.flush();
						putFile(in);
						break;
					} else if (strCommand.equals("REMOVE")) {
						boolean result=false;
						File file=getFile(tokenizer);
						if (Debug.DEBUG) {
							Debug.println("Server("+m_id+"): deleting "+file.getName()+".");
						}
						result=file.delete();
						/*
					  	 To make sure the message file array is up to
					  	 date, we invalidate the list so that it is
					  	 recreated.
						*/
						invalidateList();
						if (result) {
							writer.write("OK\n");
						} else {
							writer.write("Er\n");
						}
						writer.flush();
					} else {
						if (Debug.ERROR) {
							Debug.println("Server("+m_id+"): unrecognized command: " + strCommand);
						}
					}
				} catch (IndexOutOfBoundsException ioobe) {
					if (ioobe.getMessage()!="" && Debug.ERROR) {
						Debug.println("Server("+m_id+"): "+ioobe.getMessage());
					}
					writer.write("Er\n");
					writer.flush();
				}
			}
		} catch (IOException e) {
			if (Debug.ERROR) {
				Debug.println("Server("+m_id+"): "+e.getMessage());
			}
		}
		if (Debug.DEBUG) {
			Debug.println("Server("+m_id+"): finish thread.");
		}
	}

	private void putFile(InputStream in) throws IOException {
		String	strFilename = getOutputFilename();
		FileOutputStream fos = new FileOutputStream(strFilename);
		long written=0;
		if (Debug.DEBUG) {
			Debug.println("Server("+m_id+"): opened file: " + strFilename);
		}
		if (Debug.DEBUG) {
			Debug.println("Server("+m_id+"): now waiting for data");
		}
		int	nRead=-1;
		while (true) {
			try {
				nRead = in.read(aBytes);
			} catch (IOException ioe) {}

			if (Debug.SLOW_NET_UPLOAD) {
				try {
					sleep(10);
				} catch (InterruptedException ie) {}

			}
			if (Debug.TRACE_READWRITE) {
				Debug.println("Server("+m_id+"): received data: " + nRead);
			}
			if (nRead >= 0) {
				fos.write(aBytes, 0, nRead);
				if (written==0 && Debug.DEBUG) {
					Debug.println("Server("+m_id+"): start getting data.");
				}
				written+=nRead;
			} else {
				/*
				  We reached the end of the input stream, i.e.
				  the peer has closed the socket connection.
				  This is out signal to close the file the message
				  is written to.
				*/
				fos.close();
				if (Debug.DEBUG) {
					Debug.println("Server("+m_id+"): closed file. Wrote "+(written/1024)+" KB ("+written+" bytes).");
				}
				break;
			}
		}
	}

	private static boolean fileExists(String filename) {
		try {
			return (new File(filename)).exists();
		} catch (Exception e) {}


		return false;
	}

	//$$fb enhanced to not overwrite files.
	private static String getOutputFilename() {
		String	strFilename = "";
		do {
			sm_nFilenameCounter++;
			strFilename = MESSAGE_DIR + File.separator
			              + AMUtil.formatNumber(sm_nFilenameCounter, 4)
			              + FILENAME_TRAILER;
		} while (fileExists(strFilename));
		return strFilename;
	}

	private String getFileDesc(File file) {
		String desc="(anonymous)";
		int formatCode=1;
		try {
			desc=AMMsgFileTool.getDescription(file);
		} catch (Exception e1) {}
		try {
			formatCode=AMMsgFileTool.getFormatCode(file);
		} catch (Exception e2) {}
		return getMessageID(file.lastModified(), file.length())
			+" "+file.length()+" "+file.lastModified()+" "+formatCode+" "+desc+"\n";
	}

	private void sendList(Writer writer) {
		invalidateList();
		File[]	aMessageFiles = getMessageFiles();
		try {
			for (int i = 0; i < aMessageFiles.length; i++) {
				writer.write(getFileDesc(aMessageFiles[i]));
			}
			if (aMessageFiles.length==0) {
				writer.write("\n");
			}

			/*
			  The empty line produced by the next statement
			  is used to signal the end of the list.
			*/
			writer.write("\n");
			writer.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}



	private File[] getMessageFiles() {
		if (m_aMessageFiles == null) {
			m_aMessageFiles = createList();
		}
		return m_aMessageFiles;
	}



	private File[] createList() {
		File	directory = new File(MESSAGE_DIR);
		File[]	aFiles = directory.listFiles();
		List	messageFiles = new ArrayList();
		for (int i = 0; i < aFiles.length; i++) {
			String	strPath = aFiles[i].getPath();
			if (! strPath.endsWith(FILENAME_TRAILER)) {
				continue;
			}
			/*if (Debug.DEBUG)
		{
				println("Server: filename: " + strPath);
		}*/
			messageFiles.add(aFiles[i]);
		}
		File[]	aMessageFiles = (File[]) messageFiles.toArray(EMPTY_FILE_ARRAY);
		return aMessageFiles;
	}



	private void invalidateList() {
		m_aMessageFiles = null;
	}



	public static void main(String[] args) {
		/*	The socket that is used to listen to incoming connections.
		 */
		ServerSocket	serverSocket = null;
		try {
			serverSocket = new ServerSocket(DEFAULT_SERVER_PORT);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		if (Debug.DEBUG) {
			Debug.println("Server: started");
		}
		int id=1;
		/*
		  Now, we're waiting for incoming connections.
		 */
		while (true) {
			if (Debug.DEBUG) {
				Debug.println("Server: waiting for connection");
			}
			Socket	socket = null;
			try {
				socket = serverSocket.accept();
			} catch (IOException e) {
				e.printStackTrace();
				System.exit(1);
			}
			if (socket != null) {
				if (Debug.DEBUG) {
					Debug.println("Server: accepted connection; spawning new thread");
				}
				new Server(socket, id++).start();
			}
		}
	}
}

/*** Server.java ***/

