/*
 *	AMClientConnection.java
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package org.jsresources.apps.am.net;

import	org.jsresources.apps.am.Debug;
import	java.io.IOException;
import	java.io.InputStream;
import	java.io.OutputStream;
import	java.io.DataOutputStream;
import	java.net.Socket;
import	java.net.SocketException;
import	java.net.URL;

/*
 * This is the client for communicating with the org.jsresources.apps.am.net.Server
 * process. You can choose to use this connection/server pair in NetConstants.
 * @see Server
 */
 
public class AMClientConnection extends ClientConnection implements NetConstants {

	private Socket m_socket;

	AMClientConnection(URL url) throws IOException {
		super(url);
		m_socket=new Socket(m_url.getHost(), m_url.getPort());
		m_socket.setSoTimeout(NET_TIMEOUT);
		m_inStream=m_socket.getInputStream();
		m_outStream=m_socket.getOutputStream();
	}

	protected void sendCommandImpl(String command, String params) throws IOException {
		DataOutputStream dataOutStream=new DataOutputStream(m_outStream);
		dataOutStream.writeBytes(command+" "+params+"\n");
		dataOutStream.flush();
		// wait for response
		byte[] buffer=new byte[3];
		if (m_inStream.read(buffer)!=3 || !(new String(buffer)).startsWith("OK")) {
			throw new IOException("Server responded with error !");
		}
	}

	public int getSendBufferSize() {
		try {
			if (m_socket!=null) {
				return m_socket.getSendBufferSize();
			}
		} catch (SocketException se) {}
		return super.getSendBufferSize();
	}
}

/*** AMClientConnection.java ***/
