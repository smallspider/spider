/*
 *	AMUtil.java
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package org.jsresources.apps.am.util;

import java.util.Calendar;
import java.util.Date;

public class AMUtil {

	public static String formatNumber(long i, int digits) {
		return formatNumberImpl(i, digits, "0");
	}

	public static String formatNumberImpl(long i, int digits, String fill) {

		int ten=10;
		String res="";
		while (digits>1) {
			if (i<ten) {
				res+=fill;
			}
			digits--;
			ten*=10;
		}
		return res+String.valueOf(i);
	}

	public static String formatMinSec(long millis) {
		if (millis<0) {
			return " error";
		} else {
			return formatNumberImpl(millis/60000, 3, " ")+":"+formatNumber((millis % 60000)/1000, 2);
		}
	}


	public static long str2long(String s, long def) {
		try {
			def=Long.parseLong(s);
		} catch (NumberFormatException nfe) {}
		return def;
	}

	/**
	 * Returns a SQL formatted date+time, like 2000-03-18 20:10:05.
	 *
	 */
	public static String getFormattedDate(long millis) {
		Calendar cal=Calendar.getInstance();
		cal.setTime(new Date(millis));
		return String.valueOf(cal.get(Calendar.YEAR))+"-"
		       +formatNumber(cal.get(Calendar.MONTH)+1, 2)+"-"
		       +formatNumber(cal.get(Calendar.DAY_OF_MONTH), 2)+" "
		       +formatNumber(cal.get(Calendar.HOUR_OF_DAY), 2)+":"
		       +formatNumber(cal.get(Calendar.MINUTE), 2)+":"
		       +formatNumber(cal.get(Calendar.SECOND), 2);
	}

	public static long align(long value, int al) {
		int rest=(int) (value % (long) al);
		if (rest>al/2) {
			return value+(al-rest);
		}
		return value-rest;
	}
}

/*** AMUtil.java ***/

