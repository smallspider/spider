/*
 *	AudioCapture.java
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package org.jsresources.apps.am.audio;

import	org.jsresources.apps.am.Debug;
import	java.io.*;
import	javax.sound.sampled.*;

// class that provides an AudioInputStream that reads its data from the soundcard input
public class AudioCapture implements LineListener {

	private AudioInputStream m_stream;
	private AudioFormat m_format;
	private int m_formatCode;
	private long m_startTime;

	private int bufferSizeDefault;
	private int bufferSize;
	private TargetDataLine m_line;

	public AudioCapture(int formatCode) {
		super();
		m_format = AMAudioFormat.getLineAudioFormat(formatCode);
		m_formatCode=formatCode;
	    bufferSizeDefault = (int) m_format.getSampleRate(); // 500ms
	}

	public void update(LineEvent event) {
		if (Debug.DEBUG) {
			if (event.getType().equals(LineEvent.Type.STOP)) {
				Debug.println("Record: Stop");
			} else if (event.getType().equals(LineEvent.Type.START)) {
				Debug.println("Record: Start");
			} else if (event.getType().equals(LineEvent.Type.OPEN)) {
				Debug.println("Record: Open");
			} else if (event.getType().equals(LineEvent.Type.CLOSE)) {
				Debug.println("Record: Close");
			}
		}
		if (event.getType().equals(LineEvent.Type.START)) {
	    	m_startTime=System.currentTimeMillis();
	    } else
	    if (event.getType().equals(LineEvent.Type.STOP) 
	    	|| event.getType().equals(LineEvent.Type.CLOSE)) {
		    m_startTime=0;
		}
	}

	// opens the sound hardware
	public void open() throws Exception {
		DataLine.Info info = new DataLine.Info(TargetDataLine.class, m_format);

		// get and open the target data line for capture.
		m_line = null;
		try {
			m_line = (TargetDataLine) AudioSystem.getLine(info);
			m_line.addLineListener(this);
			if (Debug.DEBUG) {
				Debug.println("Got TargetDataLine "+m_line.getClass());
			}
			m_line.open(m_format, bufferSizeDefault);
		} catch (LineUnavailableException ex) {
			throw new Exception("Unable to open the line: "+ex.getMessage());
		}
		bufferSize = m_line.getBufferSize();
		if (Debug.TRACE) {
			Debug.println("Recording buffersize="+bufferSize+" bytes.");
		}
		
		//see below
		//m_stream = new AudioInputStream(m_line);
		m_stream = new AudioInputStream(new TargetDataLineIS(m_line), m_line.getFormat(), AudioSystem.NOT_SPECIFIED);
	}

	public AudioInputStream getAudioInputStream() {
		return m_stream;
	}

	public int getBufferSizeInBytes() {
		return bufferSize;
	}

	public int getFormatCode() {
		return m_formatCode;
	}

	public void start() throws Exception {
		m_line.flush();
		m_line.start();
	}

	public void close() {
		if (m_stream!=null) {
			if (Debug.TRACE) {
				Debug.println("AudioCapture.close(): begin");
			}
			try {
				m_stream.close();
				// hmmm... the next lines cause a deadlock...
				// but the above doesn't close the line !
				//if (m_line!=null) {
				//	m_line.close();
				//}
			}
			catch(IOException ioe) {}

			if (Debug.TRACE) {
				Debug.println("AudioCapture.close(): end");
			}
		}
	}

	public long getTime() {
		if (m_startTime!=0) {
			return System.currentTimeMillis()-m_startTime;
		} else {
			return -1;
		}
	}

	//////////////////////////////////////////////////////////////////////

	// Bug: the implementation of "new AudioInputStream(TargetDataLine)" does
	// not forward close() to the line !
	// so this is a blunt copy of Sun's implementation !
	private class TargetDataLineIS extends InputStream {
		TargetDataLine line;

		TargetDataLineIS(TargetDataLine line) {
			super();
			this.line = line;
		}

		public int available() throws IOException {
			return line.available();
		}

		public int read() throws IOException {
			byte[] b = new byte[1];

			int value = read (b, 0, 1);

			if (value == -1) {
				return -1;
			}
			return (int)b[0];
		}


		public int read(byte[] b, int off, int len) throws IOException {
			try {
				return line.read(b, off, len);
			} catch (IllegalArgumentException e) {
				throw new IOException(e.getMessage());
			}
		}

		public void close() throws IOException {
			// SunBug: strangely enough, the line needs to be flushed and
			// stopped to avoid a dead lock...
			if (line.isActive()) {
				line.flush();
				line.stop();
			}
			line.close();
		}
	} // TargetDataLineIS

}


/*** AudioCapture.java ***/
