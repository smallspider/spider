/*
 *	BufferQueue.java
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package org.jsresources.apps.am.util;

import	java.util.LinkedList;
import	java.util.NoSuchElementException;


public class BufferQueue {

	private long sizeInBytes;
	private LinkedList list;
	private boolean addLast;

	public BufferQueue() {
		this(false);
	}

	public BufferQueue(boolean addLast) {
		super();
		list=new LinkedList();
		sizeInBytes=0;
		this.addLast=addLast;
	}

	public synchronized void addBuffer(byte[] buffer) {
		if (buffer!=null) {
			if (addLast) {
				list.addLast(buffer);
			} else {
				list.addFirst(buffer);
			}
			sizeInBytes+=buffer.length;
		}
	}

	// returns null if empty
	public synchronized byte[] removeBuffer() {
		byte[] result=null;
		if (availableBuffers()>0) {
			try {
				if (addLast) {
					result=(byte[]) list.removeFirst();
				} else {
					result=(byte[]) list.removeLast();
				}
				sizeInBytes-=result.length;
			} catch (NoSuchElementException nsee) {}

		}
		return result;
	}

	protected synchronized byte[] getBuffer(int index) throws IndexOutOfBoundsException {
		return (byte[]) list.get(index);
	}

	protected synchronized byte[] getLastBuffer() {
		if (availableBuffers()>0) {
			return (byte[]) list.getLast();
		} else {
			return null;
		}
	}

	public synchronized void clear() {
		list.clear();
		sizeInBytes=0;
	}

	public synchronized int availableBuffers() {
		return list.size();
	}

	public synchronized long availableBytes() {
		return sizeInBytes;
	}

	protected synchronized void addAvailableBytes(long add) {
		sizeInBytes+=add;
	}

	// pre-conditions:
	// - synchronized block
	// - availableBuffers()>0
	private int getLastBufferSize() {
		return getBuffer(availableBuffers()-1).length;
	}

	public synchronized void shrink(long minBytes) {
		while (availableBuffers()>0 && availableBytes()-getLastBufferSize()>minBytes) {
			removeBuffer();
		}
	}

} // BufferQueue.java


/*
 
 
*/