/*
 *	OwnerClient.java
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package org.jsresources.apps.am;

import	org.jsresources.apps.am.audio.AMAudioFormat;
import	org.jsresources.apps.am.audio.AMMsgFileTool;
import	org.jsresources.apps.am.audio.AudioPlayStream;
import	org.jsresources.apps.am.audio.BufferQueueStream;
import	org.jsresources.apps.am.audio.Synchronizer;
import	org.jsresources.apps.am.net.ClientConnection;
import	org.jsresources.apps.am.util.AMTimer;
import	org.jsresources.apps.am.util.AMUtil;
import	org.jsresources.apps.am.gui.AMListener;
import	java.io.IOException;
import	java.io.InterruptedIOException;
import	java.io.InputStream;
import	java.io.DataOutputStream;
import	java.util.StringTokenizer;
import	java.util.ArrayList;
import	java.util.Collection;
import	java.util.Iterator;
import	java.util.List;
import	java.util.Comparator;
import	java.util.Collections;
import	java.net.Socket;
import	java.net.URL;
import	javax.sound.sampled.LineEvent;
import	javax.sound.sampled.LineListener;
import	javax.sound.sampled.AudioSystem;
import	javax.sound.sampled.AudioFormat;
import	javax.sound.sampled.AudioInputStream;
import	javax.sound.sampled.UnsupportedAudioFileException;

public class OwnerClient implements LineListener {

	private URL m_url;
	
	// event support
	private AMListener m_listener;
	private Object m_lastBufferingObject;
	public static final int BUFFERING_START=1;
	public static final int BUFFERING_STOP=2;
	public static final int PLAYBACK_START=3;
	public static final int PLAYBACK_STOP=4;
	
	// play support
	private Message m_currPlayingMessage;
	private Message m_currentBufferingMessage;
	private Synchronizer m_sync;
	private AudioPlayStream m_aps;

	public OwnerClient(URL url) {
		if (Debug.DEBUG) {
			Debug.println("OwnerClient("+url+")");
		}
		m_url=url;
	}
	
	public void setAMListener(AMListener listener) {
		m_listener=listener;
	}

	private void onBufferingStateChange(Object o, boolean starting) {
		if (m_listener!=null) {
			if (!starting && o==m_lastBufferingObject) {
				m_listener.onStateChange(this, BUFFERING_STOP);
			} 
			else if (starting) {
				m_listener.onStateChange(this, BUFFERING_START);
				m_lastBufferingObject=o;
			}
		}
	}
	
	private void onProgressChange(Object sender) {
		if (m_listener!=null) {
			try {
				m_listener.onProgress(sender);
			} catch (Throwable t) {
				if (Debug.SHOW_ALL_EXCEPTIONS) {
					Debug.println(t);
				}
			}
		}
	}

	private void onPlayStateChange(boolean starting) {
		if (m_listener!=null) {
			try {
				if (!starting) {
					m_listener.onStateChange(this, PLAYBACK_STOP);
				} 
				else {
					m_listener.onStateChange(this, PLAYBACK_START);
				}
			} catch (Throwable t) {
				if (Debug.SHOW_ALL_EXCEPTIONS) {
					Debug.println(t);
				}
			}
		}
	}

	// SourceDataLine events
	public void update(LineEvent event) {
		// we only want the stop event
		// the start event is handled in play
		if (m_listener!=null) {
			if (event.getType().equals(LineEvent.Type.STOP)) {
				onPlayStateChange(false);
			}
		}
	}

	public Collection getList() throws Exception {
		return getList(null);
	}

	public Collection getList(Collection oldList) throws Exception {
		if (Debug.TRACE_INOUT) {
			Debug.println("OwnerClient.getList(): begin");
		}
		Collection res=null;
		ClientConnection conn=ClientConnection.getClientConnection(m_url);
		try {
			res=getListImpl(conn, oldList);
		}
		finally {
			conn.close();
		}
		if (Debug.TRACE_INOUT) {
			Debug.println("OwnerClient.getList(): end");
		}
		return res;
	}

	private Collection getListImpl(ClientConnection conn, Collection oldList) throws Exception {
		String s="";
		conn.sendCommand("list");
		byte[] buffer=new byte[2048];
		int len;
		do {
			len=conn.read(buffer);
			if (len>0) {
				s+=new String(buffer, 0, len);
				if (s.endsWith("\n\n")) {
					break;
				}
			}
		} while (len>=0);
		StringTokenizer	tokenizer = new StringTokenizer(s, "\n");
		ArrayList result=new ArrayList();
		int i=0;
		while (tokenizer.hasMoreTokens()) {
			String line = tokenizer.nextToken().trim();
			if (line.length()>0) {
				try {
					result.add(new Message(line));
				} catch (Exception e) {
					if (Debug.ERROR) {
						Debug.println(e.getMessage());
					}
				}
			}
		}
		// now see if there has been same messages
		if (oldList!=null && (oldList instanceof List)) {
			List oList=(List) oldList;
			for (int x=0; x<result.size(); x++) {
				int index=oList.indexOf(result.get(x));
				if (index>=0) {
					result.set(x, oList.get(index));
				}
			}
		}
		sortList(result);
		return result;
	}

	private void sortList(ArrayList list) {
		Collections.sort(list, new Comparator() {
			                 public int compare(Object o1, Object o2) {
				                 if ((o1 instanceof Message) && (o2 instanceof Message)) {
					                 return (int) (((Message) o2).getDate()-((Message) o1).getDate());
				                 }
				                 return 0;
			                 }
		                 }
		                );
	}


	public Collection remove(Message msg) throws Exception {
		return remove(msg, null);
	}

	public Collection remove(Message msg, Collection oldList) throws Exception {
		if (Debug.TRACE_INOUT) {
			Debug.println("OwnerClient.remove(\""+msg+"\"): begin");
		}
		Collection res=null;
		ClientConnection conn=ClientConnection.getClientConnection(m_url);
		try {
			conn.sendCommand("remove", msg.getID());
			res=getListImpl(conn, oldList);
		}
		finally {
			conn.close();
		}
		if (Debug.TRACE_INOUT) {
			Debug.println("OwnerClient.remove(\""+msg+"\"): end");
		}
		return res;
	}

	public InputStream getInputStream(String ID, long position) throws Exception {
		if (Debug.TRACE_INOUT) {
			Debug.println("OwnerClient.getInputStream("+ID+", "+position+"): begin");
		}
		ClientConnection conn=ClientConnection.getClientConnection(m_url);
		if (position==0) {
			conn.sendCommand("get", ID);
		} else {
			conn.sendCommand("get", ID+" "+position);
		}
		if (Debug.TRACE_INOUT) {
			Debug.println("OwnerClient.getInputStream("+ID+", "+position+"): end");
		}
		return conn.getInputStream();
	}

	public synchronized void close(boolean immediate) throws Exception {
		if (Debug.TRACE_INOUT) {
			Debug.println("OwnerClient.close(): begin");
		}
		String error="";
		if (m_currPlayingMessage!=null) {
			m_currPlayingMessage.setImmediateStop(immediate);
		}

		if (m_sync!=null) {
			if (Debug.TRACE) {
				Debug.println("OwnerClient.close(): Stopping Synchronizer "+(immediate?"":"not ")+"immediate");
			}
			try {
				m_sync.stop(immediate);
			} catch (Exception e2) {
				error+="   "+e2.getMessage();
			}
			m_sync=null;
		}
		if (m_aps!=null) {
			try {
				m_aps.close(immediate);
			} catch (Exception e1) {
				error+="   "+e1.getMessage();
			}
			m_aps=null;
		}
		if (m_currPlayingMessage!=null) {
			if (Debug.TRACE) {
				Debug.println("OwnerClient.close(): Stopping buffering");
			}
			try {
				m_currPlayingMessage.close();
			} catch (Exception e3) {
				error+="   "+e3.getMessage();
			}
			//m_currPlayingMessage=null;
		}

		if (error!="") {
			throw new Exception(error);
		}
		if (Debug.TRACE_INOUT) {
			Debug.println("OwnerClient.close(): end");
		}
	}

	public void startBuffering(Message msg) {
		startBuffering(msg, -1);
	}

	public void startBuffering(Message msg, long maxBuffer) {
		if (m_currentBufferingMessage!=null && msg!=m_currentBufferingMessage) {
			m_currentBufferingMessage.stopBuffering();
		}
		m_currentBufferingMessage=msg;
		m_currentBufferingMessage.startBuffering(maxBuffer);
	}

	public synchronized void play(Message msg) throws Exception {
		if (Debug.TRACE_INOUT) {
			Debug.println("OwnerClient.play(): begin");
		}
		boolean playing=(m_sync!=null && m_aps!=null && m_sync.isAlive() && !m_sync.isStopping());
		if (playing) {
			if (msg==m_currPlayingMessage) {
				msg.setPos(0);
				onPlayStateChange(true);
				return;
			} 
			else if (m_currPlayingMessage!=null && m_currPlayingMessage.getFormatCode()!=msg.getFormatCode()) {
				// do not reuse an open line if format is different
				playing=false;
			}
		}
		if (!playing) {
			close(true);
		}
		try {
			AudioInputStream ais=msg.getAudioInputStream();
			if (Debug.TRACE) {
				Debug.println(this, "network format="+ais.getFormat());
			}
			startBuffering(msg);
			msg.open();
			if (msg!=m_currPlayingMessage || msg.getPos()>=msg.getAudioSize()) {
				msg.setPos(0);
			}
			// format conversion
			//ais=AudioSystem.getAudioInputStream(AMAudioFormat.getPlayAudioFormat(), ais);
			ais=org.jsresources.apps.am.audio.AMAppletWorkaround.getAudioInputStream(AMAudioFormat.getLineAudioFormat(ais.getFormat().getSampleRate()), ais);
			if (Debug.TRACE) {
				Debug.println(this, "playback format="+ais.getFormat());
			}
			if (playing) {
				if (Debug.TRACE) {
					Debug.println("OwnerClient.play(): Setting new input stream...");
				}
				m_sync.setInputStream(ais);
				m_aps.setImmediateStop(false);
				if (m_currPlayingMessage!=null) {
					m_currPlayingMessage.close();
				}
			} else {
				if (Debug.TRACE) {
					Debug.println("OwnerClient.play(): Preparing audio output...");
				}
				m_aps = new AudioPlayStream(ais.getFormat());
				m_aps.setListener(this);
				m_aps.open();

				if (Debug.TRACE) {
					Debug.println("OwnerClient.play(): Preparing synchronizer...");
				}
				// 150ms buffer size in synchronizer
				m_sync=new Synchronizer(ais, m_aps, (int) AMAudioFormat.ms2Bytes(150, ais.getFormat()));
				m_sync.setOnlyReadWhenAvailable(false);
				if (Debug.TRACE) {
					Debug.println("OwnerClient.play(): Starting audio...");
				}
				m_aps.start();
				if (Debug.TRACE) {
					Debug.println("OwnerClient.play(): Starting Synchronizer...");
				}
				m_sync.start();
			}
			m_currPlayingMessage=msg;
			onPlayStateChange(true);
			if (Debug.TRACE_INOUT) {
				Debug.println("OwnerClient.play(): end");
			}
		} catch (Exception e) {
			if (Debug.TRACE) {
				Debug.println("OwnerClient.play(): Exception occured. Closing...");
			}
			close(true);
			throw e;
		}
	}

	private void flushOutput() {
		if (m_aps!=null) {
			try {
				m_aps.flush();
				m_aps.setImmediateStop(false);
			} catch (Exception ie) {}

		}
	}

	public synchronized Message getPlayingMessage() {
		if (m_sync!=null && m_sync.isAlive()) {
			return m_currPlayingMessage;
		}
		return null;
	}

	public synchronized int getAudioBufferSize() {
		if (m_sync!=null && m_sync.isAlive() && m_aps!=null) {
			return m_aps.getBufferSize();
		}
		return 0;
	}

	//////////////////////////////////////////////////////////////////////

	public class Message {

		private long m_date=0;
		private String m_strDate;
		private long m_size=0;
		private int m_formatCode=1;
		private String m_callerName="";
		private String m_id;
		private DataHandler dataHandler;
		private AudioInputStream AIS;
		private long audioDataStart=-1;

		public Message(String line) throws Exception {
			if (Debug.TRACE) {
				Debug.println("Message <init> with line=\""+line+"\"");
			}
			StringTokenizer	tokenizer = new StringTokenizer(line);
			// 1: message id
			m_id=tokenizer.nextToken();
			// 2: message size
			m_size=AMUtil.str2long(tokenizer.nextToken(), 0);
			// 3: date
			m_date=AMUtil.str2long(tokenizer.nextToken(), 0);
			if (m_date==0 || m_size==0) {
				throw new Exception("Corrupt message: wrong size ("+m_size+") or date ("+m_date+").");
			}
			// 4: format code
			m_formatCode=(int) AMUtil.str2long(tokenizer.nextToken(), 1);
			
			// 5: caller name
			boolean hmt=tokenizer.hasMoreTokens();
			while (hmt) {
				m_callerName+=tokenizer.nextToken();
				hmt=tokenizer.hasMoreTokens();
				if (hmt) {
					m_callerName+=" ";
				}
			}
			audioDataStart=AMMsgFileTool.getHeaderSize(m_callerName);
			if (m_callerName=="") {
				m_callerName="(unknown)";
			}
			m_strDate=AMUtil.getFormattedDate(m_date);
			AIS=null;
		}

		public long getDate() {
			return m_date;
		}

		public String getStrDate() {
			return m_strDate;
		}

		public long getAudioSize() {
			return m_size-audioDataStart;
		}

		public String getCallerName() {
			return m_callerName;
		}

		public String getID() {
			return m_id;
		}

		public long getTimeMillis() {
			return AMAudioFormat.netBytes2Ms(getAudioSize(), m_formatCode);
		}

		public String getTimeStr() {
			return AMUtil.formatMinSec(getTimeMillis());
		}
		
		public int getFormatCode() {
			return m_formatCode;
		}

		// audio streaming
		
		public AudioInputStream getAudioInputStream() throws UnsupportedAudioFileException, IOException {
			if (m_size==0) {
				throw new IOException("No audio data");
			}
			if (dataHandler==null) {
				dataHandler=new DataHandler(m_size);
			} else {
				dataHandler.open();
			}
			long oldPos=dataHandler.getPos()-audioDataStart;
			dataHandler.setPos(0);
			AudioFormat format=AMMsgFileTool.readHeader(dataHandler);
			audioDataStart=dataHandler.getPos();
			//AIS=new AudioInputStream(dataHandler, format, getAudioSize());
			AIS=new AudioInputStream(dataHandler, format, AudioSystem.NOT_SPECIFIED);
			if (oldPos>0) {
				setPos(oldPos);
			}
			return AIS;
		}

		public void open() throws IOException {
			if (dataHandler!=null) {
				dataHandler.open();
			}
		}


		public long getPos() {
			if (dataHandler==null) {
				return 0;
			} else {
				return dataHandler.getPos()-audioDataStart;
			}
		}

		public long getPlayPos() {
			long res=getPos()-(getAudioBufferSize()/4);
			if (res<0) {
				res=0;
			} else if (res>getAudioSize()) {
				res=getAudioSize();
			}
			return res;
		}

		public long getPosMillis() {
			return AMAudioFormat.netBytes2Ms(getPos(), m_formatCode);
		}

		public String getPosStr() {
			return AMUtil.formatMinSec(getPosMillis());
		}

		public long setPos(long pos) {
			long res=0;
			try {
				if (dataHandler==null) {
					if (Debug.TRACE) {
						Debug.println(this, "setPos(): need to get new AIS");
					}
					getAudioInputStream();
				}
				long audioPos=AMUtil.align(pos, getPlayingAudioFormat().getFrameSize());
				if (Debug.TRACE) {
					Debug.println(this, "setPos("+pos+"): alignedPos="+audioPos+" frameSize="+getPlayingAudioFormat().getFrameSize());
				}
				res=dataHandler.setPos(audioDataStart+audioPos)-audioDataStart;
				if (Debug.TRACE) {
					Debug.println(this, "setPos("+pos+"): result="+res);
				}
			} catch (Exception e) {
				if (Debug.SHOW_ALL_EXCEPTIONS) {
					Debug.println(e);
				}
			}
			return res;
		}

		public void close() throws IOException {
			if (dataHandler!=null) {
				dataHandler.close();
			}
		}

		public void setImmediateStop(boolean value) {
			if (dataHandler!=null) {
				dataHandler.setImmediateStop(value);
			}
		}

		public void startBuffering(long max) {
			try {
				if (dataHandler==null) {
					getAudioInputStream();
				}
				dataHandler.doBuffering(max);
			} catch (Exception e) {}
		}

		public void stopBuffering() {
			if (dataHandler!=null) {
				try {
					dataHandler.stopBuffering();
				} catch (Exception e) {}

			}
		}

		public int getBufferPercent() {
			if (dataHandler==null) {
				return 0;
			}
			return dataHandler.getBufferPercent();
		}

		public int getPlayPercent() {
			return (int) Math.round(100.0f*getPlayPos()/getAudioSize());
		}

		public void setPlayPercent(int value) {
			setPos((long) Math.round(value/100.0f*getAudioSize()));
		}
	
		public AudioFormat getPlayingAudioFormat() {
			return AIS==null?null:AIS.getFormat();
		}

		public String toString() {
			return getStrDate()+"   "+getTimeStr()+"  "+getCallerName();
		}

		public boolean equals(Object o) {
			return (o instanceof Message) && ((Message) o).getID().equals(getID());
		}

		//////////////////////////////////////////////////////////////////////
		public class DataHandler extends InputStream implements AMTimer.Listener {

			private final static int BUF_SIZE=4096;

			private BufferQueueStream queue;
			private InputStream stream=null;
			private AMTimer timer;
			private long maxBufferSize;
			private boolean closed;
			private long totalSize;
			private long nextReadSetPos;
			private long m_mark=-1;
			private boolean immediateStop=false;

			public DataHandler(long totalSize) {
				super();
				this.totalSize=totalSize;
				queue=new BufferQueueStream();
				nextReadSetPos=-1;
			}

			public void setImmediateStop(boolean value) {
				immediateStop=value;
			}

			public int getBufferPercent() {
				return (int) Math.round(100.0f*queue.availableBytes()/totalSize);
			}

			public boolean bufferFull() {
				return queue.availableBytes()>=totalSize;
			}

			// can this be synchronized ?
			public synchronized void doBuffering(long maxSize) {
				if (!bufferFull()) {
					if (Debug.TRACE && (timer==null || !timer.isAlive())) {
						Debug.println(this, "start buffering");
						//Thread.dumpStack();
					}
					if (timer==null || !timer.isAlive()) {
						timer=new AMTimer(this);
						timer.setInterval(30);
					}
					if (maxSize<0 || maxSize>totalSize) {
						maxBufferSize=totalSize;
					} else {
						maxBufferSize=maxSize;
					}
					if (!timer.isAlive()) {
						timer.start();
					}
					onBufferingStateChange(this, true);
				} else {
					stopBuffering();
				}
			}

			public synchronized void stopBuffering() {
				if (Debug.DEBUG && (timer!=null || stream!=null)) {
					Debug.println(this, "stop buffering");
					//Thread.dumpStack();
				}
				if (timer!=null) {
					timer.terminate();
					timer=null;
				}
				if (stream!=null) {
					try {
						stream.close();
					} catch (IOException ie) {}
					stream=null;
				}
				this.notifyAll();
				onBufferingStateChange(this, false);
			}

			public boolean onTimer() {
				try {
					// if stream has been shut down previously, open it again
					if (stream==null) {
						if (!bufferFull()) {
							stream=getInputStream(getID(), queue.availableBytes());
							if (stream==null) {
								stopBuffering();
								return false;
							}
						} else {
							stopBuffering();
							return false;
						}
					}
					while (stream!=null && stream.available()>0
					        && timer!=null && !timer.isTerminating()) {
						byte[] buffer=new byte[BUF_SIZE];
						int res=-1;
						try {
							res=stream.read(buffer, 0, BUF_SIZE);
						} catch (InterruptedIOException iie) {
							res=0; // timeout
						}

						catch (IOException ioe) {}

						if (res==-1) {
							// stream has been closed
							// do not buffer anymore
							stopBuffering();
							return false;
						} else if (res<BUF_SIZE && res>0) {
							// need to create a new buffer object...
							// happens only at end of stream (I hope)
							byte[] buffer2=new byte[res];
							System.arraycopy(buffer, 0, buffer2, 0, res);
							buffer=buffer2;
						}
						if (res>0) {
							queue.addBuffer(buffer);
							onProgressChange(this);
							if (bufferFull()) {
								// queue is filled enough
								stopBuffering();
								return false;
							}
						}
					}
				} catch (Throwable t) {
					if (Debug.ERROR) {
						Debug.println(t);
					}
					stopBuffering();
					try {
						close(true);
					} catch (IOException e) {}
					return false;
				}
				return true;
			}

			public synchronized int read() throws IOException {
				byte[] hack=new byte[1];
				if (read(hack, 0, 1)==1) {
					return hack[0] & 0xFF;
				}
				return -1;
			}

			private synchronized void checkBuffer() {
				if (!bufferFull() && (stream==null || timer==null || !timer.isAlive())) {
					doBuffering(totalSize);
				}
			}

			public int read(byte b[]) throws IOException {
				return read(b, 0, b.length);
			}

			public int read(byte b[], int off, int len) throws IOException {
				if (Debug.TRACE_READWRITE) {
					Debug.println(this, "read(buffer, off, "+len+")");
				}
				if (closed) {
					if (Debug.TRACE) {
						Debug.println(this, "read: closed->return -1");
					}
					return -1;
				}
				if (len==0) {
					if (Debug.TRACE) {
						Debug.println(this, "read: len==0->return 0");
					}
					return 0;
				}
				checkBuffer();
				do {
					long needAvail=len;
					if (nextReadSetPos>=0) {
						// need to set position
						setPosImpl(nextReadSetPos);
					}
					if (nextReadSetPos>=0) {
						if (closed) {
							return 0;
						}
						needAvail=nextReadSetPos-queue.getPos();
					} else {
						if (queue.getPos()+needAvail>totalSize) {
							needAvail=totalSize-queue.getPos();
						}
						if (needAvail==0) {
							if (Debug.TRACE) {
								Debug.println(this, "read: try to read past end ->return -1");
							}
							return -1;
						}
						if (queue.availableRead()>=needAvail) {
							len=(int) needAvail;
							break;
						}
					}
					long lastNextReadSetPos=nextReadSetPos;
					if (Debug.TRACE) {
						Debug.println(this, "read: wait for data");
					}
					while (queue.availableRead()<needAvail && !closed && lastNextReadSetPos==nextReadSetPos) {
						synchronized (this) {
							try {
								this.wait(100);
							} catch (InterruptedException ie) {}
						}
					}
				} while (nextReadSetPos>=0);
				int toRead=(int) queue.availableRead();
				if (toRead>len) {
					toRead=len;
				}
				if (Debug.TRACE_READWRITE) {
					Debug.println(this, "read: reading "+toRead+" bytes from buffer. Available="+queue.availableRead());
				}
				int res=queue.read(b, off, toRead);
				onProgressChange(this);
				if (Debug.TRACE_READWRITE) {
					Debug.println(this, "read: returning "+res+" bytes");
				}
				return res;
			}

			public long skip(long n) throws IOException {
				return setPos(queue.getPos()+n);
			}

			private synchronized long setPosImpl(long pos) {
				if (Debug.TRACE) {
					Debug.println(this, "setPosImpl("+pos+")");
				}
				long len=pos-queue.getPos();
				if (len>0 && queue.availableRead()<len) {
					nextReadSetPos=pos;
				} else {
					nextReadSetPos=-1;
					queue.setPos(pos);
				}
				return pos;
			}

			public long setPos(long pos) {
				checkBuffer();
				if (pos>totalSize) {
					pos=totalSize;
				} else if (pos<0) {
					pos=0;
				}
				long res=setPosImpl(pos);
				flushOutput();
				synchronized (this) {
					this.notifyAll();
				}
				immediateStop=false;
				return res;
			}

			public synchronized long getPos() {
				if (nextReadSetPos>=0) {
					return nextReadSetPos;
				}
				return queue.getPos();
			}


			public synchronized int available() throws IOException {
				if (nextReadSetPos>=0) {
					return (int) (queue.availableRead()+queue.getPos()-nextReadSetPos);
				}
				return (int) queue.availableRead();
			}

			public synchronized void mark(int readlimit) {
				m_mark=getPos();
			}

			// reverts a closed stream to open :)
			public synchronized void reset() throws IOException {
				open();
				if (m_mark!=-1) {
					setPos(m_mark);
				} else {
					setPos(0);
				}
			}

			public synchronized void open() throws IOException {
				immediateStop=false;
				closed=false;
			}

			public boolean markSupported() {
				return true;
			}

			public void close() throws IOException {
				close(immediateStop);
			}

			public void close(boolean immediate) throws IOException {
				if (Debug.TRACE) {
					Debug.println(this, "close(immediate="+immediate+")");
				}
				closed=true;
				//stopBuffering();
				if (immediate) {
					synchronized(this) {
						this.notifyAll();
					}
				}
				immediateStop=false;
			}

			public synchronized void flush() throws IOException {
				immediateStop=true;
				this.notifyAll();
			}

		} // AudioDataHandler
	} // Message
}
/*** OwnerClient.java ***/

