/*
 *	OwnerClientPanel.java
 *
 *	GUI to listen to recorded audio from a server.
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package org.jsresources.apps.am.gui;

import	org.jsresources.apps.am.Debug;
import	org.jsresources.apps.am.OwnerClient;

import	java.awt.AWTEvent;
import	java.awt.BorderLayout;
import	java.awt.FlowLayout;
import	java.awt.GridLayout;
import	java.awt.Font;

import	java.awt.event.ActionEvent;
import	java.awt.event.ActionListener;
import	java.awt.event.ComponentEvent;
import	java.awt.event.MouseAdapter;
import	java.awt.event.MouseEvent;
import	java.net.URL;

import	javax.swing.JList;
import	javax.swing.JSeparator;
import	javax.swing.DefaultListModel;
import	javax.swing.ListSelectionModel;
import	javax.swing.ListModel;
import	javax.swing.JScrollPane;

import	javax.swing.JButton;
import	javax.swing.SwingConstants;
import	javax.swing.JLabel;
import	javax.swing.JPanel;
import	javax.swing.JTextField;
import	javax.swing.JOptionPane;
import	javax.swing.JProgressBar;
import	javax.swing.JSlider;

import	java.util.Collection;
import	java.util.Iterator;

import	javax.sound.sampled.AudioFormat;

/*
 Listen to the answering machine
 ----
 Message 1
 Message 2
 Message 3
 Message 4
 -----
                   
 Play Stop Remove Refresh
                   
 -----
 Playing: ------------T----------
 Buffer:  --------33%------------
 -----
 Status
*/

public class OwnerClientPanel extends AMPanel implements AMListener {

	private JButton		m_playButton;
	private JButton		m_stopButton;
	private JButton		m_removeButton;
	private JButton		m_refreshButton;
	private JList		m_list;
	private JProgressBar m_progressBar;
	private JSlider		m_slider;

	private OwnerClient	m_client=null;
	private Collection	currentMessages=null;
	
	// events for asynchronous actions
	private final static int REFRESH_EVENT=AWTEvent.RESERVED_ID_MAX+100;
	private final static int EXCEPTION_EVENT=AWTEvent.RESERVED_ID_MAX+101;
	private final static int PROGRESS_EVENT=AWTEvent.RESERVED_ID_MAX+102;

	public OwnerClientPanel(String title, URL url) {
		super(title, url);
		m_client=new OwnerClient(url);
		m_client.setAMListener(this);

		setLayout(new BorderLayout());

		JPanel panel=new JPanel();
		panel.setLayout(new StripeLayout(4));
		panel.add(m_titleLabel);
		panel.add(new JSeparator());
		add("North", panel);

		m_list=new JList();
		m_list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		m_list.addMouseListener(new MouseAdapter() {
			                        public void mouseClicked(MouseEvent e) {
				                        if (e.getClickCount() == 2) {
					                        startPlay();
				                        }
				                        else if (e.getClickCount() == 1) {
					                        showProgress(m_client.getPlayingMessage());
				                        }
			                        }});
		m_list.setModel(new DefaultListModel());
		add("Center", new JScrollPane(m_list));

		JPanel panel1=new JPanel();
		panel1.setLayout(new FlowLayout());
		m_playButton=new JButton("Play");
		m_playButton.addActionListener(new ActionListener() {
			                               public void actionPerformed(ActionEvent ae) {
				                               startPlay();
			                               }});
		panel1.add(m_playButton);
		m_stopButton=new JButton("Stop");
		m_stopButton.addActionListener(new ActionListener() {
			                               public void actionPerformed(ActionEvent ae) {
				                               stopPlay();
			                               }});
		panel1.add(m_stopButton);

		m_removeButton=new JButton("Remove");
		m_removeButton.addActionListener(new ActionListener() {
			                                 public void actionPerformed(ActionEvent ae) {
				                                 remove();
			                                 }});
		panel1.add(m_removeButton);

		m_refreshButton=new JButton("Refresh");
		m_refreshButton.addActionListener(new ActionListener() {
			                                  public void actionPerformed(ActionEvent ae) {
				                                  refresh();
			                                  }});
		panel1.add(m_refreshButton);

		JPanel southPanel=new JPanel();
		southPanel.setLayout(new StripeLayout(4));
		southPanel.add(panel1);

		panel1=new JPanel();
		panel1.setLayout(new GridLayout(2,1));
		panel1.add(new JLabel("Playing: "));
		panel1.add(new JLabel("Buffer: "));

		JPanel panel2=new JPanel();
		panel2.setLayout(new GridLayout(2,1));
		m_slider=new JSlider(0, 100, 0);
		m_slider.setSnapToTicks(false);
		m_slider.setMinorTickSpacing(10);
		m_slider.setMajorTickSpacing(10);
		m_slider.addMouseListener(new MouseAdapter() {
			                          public void mouseReleased(MouseEvent e) {
				                          sliderAdjusted();
			                          }});
		panel2.add(m_slider);
		m_progressBar=new JProgressBar(0, 100);
		m_progressBar.setValue(0);
		panel2.add(m_progressBar);

		panel=new JPanel();
		panel.setLayout(new BorderLayout());
		panel.add("West", panel1);
		panel.add("Center", panel2);
		southPanel.add(panel);
		southPanel.add(new JSeparator());

		southPanel.add(m_status);
		add("South", southPanel);
	}

	public void afterShow() {
		super.afterShow();
		dispatchEvent(REFRESH_EVENT);
	}

	protected void processEvent(AWTEvent e) {
		if (e.getID()==REFRESH_EVENT) {
			refresh();
		} else 
		if (e.getID()==EXCEPTION_EVENT) {
			if (e.getSource() instanceof Throwable) {
				handleException((Throwable) e.getSource());
			}
		} else 
		if (e.getID()==PROGRESS_EVENT) {
			showProgress(m_client.getPlayingMessage());
		} else {
			super.processEvent(e);
		}
	}

	private static final OwnerClient.Message[] EMPTY_MESSAGE_ARRAY = new OwnerClient.Message[0];

	public synchronized void refresh() {
		try {
			beginWait();
			try {
				refreshImpl(m_client.getList(currentMessages));
			} finally {
				endWait();
			}
		} catch (Throwable t) {
			handleException(t);
		}
	}

	private synchronized String getSelectedID() {
		OwnerClient.Message msg=getSelectedMessageImpl();
		if (msg!=null) {
			return msg.getID();
		}
		return "";
	}

	private synchronized int findID(String ID) {
		ListModel lm=m_list.getModel();
		for (int i=0; i<lm.getSize(); i++) {
			OwnerClient.Message msg=(OwnerClient.Message) lm.getElementAt(i);
			if (ID.equals(msg.getID())) {
				return i;
			}
		}
		return -1;
	}

	private synchronized void refreshImpl(Collection c) {
		try {
			String selID=getSelectedID();
			int index=m_list.getSelectedIndex();
			m_list.setListData(c.toArray(EMPTY_MESSAGE_ARRAY));
			currentMessages=c;
			int newIndex=findID(selID);
			if (newIndex<0) {
				newIndex=index;
			}
			if (newIndex>=getCount()) {
				newIndex=getCount()-1;
			}
			m_list.setSelectedIndex(newIndex);
			status(""+getCount()+" messages on server");
		} catch (Throwable t) {
			handleException(t);
		}
	}

	private void remove() {
		try {
			beginWait();
			try {
				refreshImpl(m_client.remove(getSelectedMessage(), currentMessages));
			} finally {
				endWait();
			}
		} catch (Throwable t) {
			handleException(t);
		}
	}

	private void startPlay()	{
		OwnerClient.Message msg=getSelectedMessageImpl();
		if (msg!=null) {
			try {
				beginWait();
				try {
					m_client.play(msg);
				} finally {
					endWait();
				}
			} catch (Throwable t) {
				handleException(t);
			}
		}
	}

	private void stopPlay() {
		try {
			m_client.close(true);
		} catch (Throwable t) {
			handleException(t);
		}
	}

	public void sliderAdjusted() {
		int value=m_slider.getValue();
		OwnerClient.Message msg=getSelectedMessageImpl();
		if (msg!=null) {
			msg.setPlayPercent(value);
		}
	}

	private OwnerClient.Message getSelectedMessage() throws Exception {
		OwnerClient.Message msg=getSelectedMessageImpl();
		if (msg==null) {
			throw new Exception("You haven't selected any message !");
		}
		return msg;
	}

	private OwnerClient.Message getSelectedMessageImpl() {
		if (m_list.getSelectedIndex()<0 || m_list.getSelectedIndex()>=getCount()) {
			return null;
		}
		return (OwnerClient.Message) m_list.getSelectedValue();
	}

	private int getCount() {
		return m_list.getModel().getSize();
	}

	public void onProgress(Object sender) {
		// this is timing-sensitive. dispatch it to the AWT thread
		dispatchEvent(PROGRESS_EVENT);
	}
			
	public void onStateChange(Object sender, int state) {
		if (state==OwnerClient.BUFFERING_START) {
			statusBeginConnecting();
		} else
		if (state==OwnerClient.PLAYBACK_START) {
			AudioFormat format=null;
			OwnerClient.Message msg=m_client.getPlayingMessage();
			if (msg!=null) {
				format=msg.getPlayingAudioFormat();
			}
			if (format!=null) {
				status("Playing "+format.getEncoding()+" encoded data at "+((int) format.getSampleRate())+"Hz");
			} else {
				status("Started playback");
			}
		} else
		if (state==OwnerClient.PLAYBACK_STOP) {
			status("Playback stopped.");
		}
		showProgress();
	}

	public void onException(Throwable t) {
		dispatchEvent(new AMEvent(t, EXCEPTION_EVENT));
	}

	private void showProgress() {
		showProgress(null);
	}

	private void showProgress(OwnerClient.Message msg) {
		int value=0;
		int play=0;
		if (msg==null) {
			msg=getSelectedMessageImpl();
			if (msg!=null) {
				value=msg.getBufferPercent();
				play=msg.getPlayPercent();
			}
		}
		else {
			value=msg.getBufferPercent();
			play=msg.getPlayPercent();
		}
		if (!m_slider.getValueIsAdjusting()) {
			m_slider.setValue(play);
		}
		m_progressBar.setValue(value);
	}

	public void destroyImpl() {
		if (m_client!=null) {
			m_client.setAMListener(null);
			stopPlay();
			m_client=null;
		}
	}
}

/*** OwnerClientPanel.java ***/
