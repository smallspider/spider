/*
 *	HttpClientConnection.java
 *
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package org.jsresources.apps.am.net;

import	org.jsresources.apps.am.Debug;
import	java.io.IOException;
import	java.io.InputStream;
import	java.io.OutputStream;
import	java.io.DataOutputStream;
import	java.net.*;

/**
 * Communicating with the server over the HTTP protocol.
 * Internally it uses an HttpURLConnection. This has
 * the problem that it buffers all in/out data until
 * i/o is finished. Then, at last, the actual request to
 * the server is sent.
 * Problems: 
 * PUT: we cannot record at the same time as sending data
 *      over the net - it is written to the buffer and at last
 *      written to the net - when recording has finished.
 * GET: All data is gathered from the net and then returned
 *      to the applciation. We cannot play while it is still
 *      downloading.
 */

public class HttpClientConnection extends ClientConnection {

	private DataOutputStream m_dataOutStream;
	HttpURLConnection m_connection;

	HttpClientConnection(URL url) {
		super(url);
	}
	
	protected void sendCommandImpl(String command, String params) throws IOException {
		close();
		URLConnection uc=getHttpURL(params).openConnection();
		if (!(uc instanceof HttpURLConnection)) {
			throw new IOException("Not a http connection !");
		}
		m_connection=(HttpURLConnection) uc;
		m_connection.setDoOutput(m_doOutput);
		m_connection.setDoInput(true);
		m_connection.setUseCaches(false);
		m_connection.setRequestMethod(command);
		m_connection.connect();
		if (!m_doOutput && m_connection.getResponseCode()!=200) {
			throw new IOException("Server error: "+m_connection.getResponseMessage());
		}
	}

	public InputStream getInputStream() throws IOException {
		super.getInputStream();
		if (m_connection==null) {
			throw new IOException("URL connection not opened !");
		}
		if (m_inStream==null) {
			m_inStream=m_connection.getInputStream();
		}
		return m_inStream;
	}

	public OutputStream getOutputStream() throws IOException {
		super.getOutputStream();
		if (m_connection==null) {
			throw new IOException("URL connection not opened !");
		}
		if (m_outStream==null) {
			m_outStream=m_connection.getOutputStream();
		}
		return m_outStream;
	}
	
	public void close() {
		boolean didOutput=m_outStream!=null;
Debug.println("didOutput:"+didOutput+" m_connection: "+(m_connection!=null));		
		super.close();
		if (didOutput && m_connection!=null) {
			// need to actually do the network connection
			try {
				String response=m_connection.getResponseMessage();
				if (Debug.DEBUG) {
					Debug.println("Server: "+response);
				}
			} catch (IOException ioe) {
				if (Debug.SHOW_ALL_EXCEPTIONS) {
					Debug.println(ioe);
				}
			}
		}
	}
	
}

/*** HttpClientConnection.java ***/
