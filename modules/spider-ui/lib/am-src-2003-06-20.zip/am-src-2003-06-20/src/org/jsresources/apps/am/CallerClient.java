/*
 *	CallerClient.java
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package org.jsresources.apps.am;

import	org.jsresources.apps.am.util.BufferQueue;
import	org.jsresources.apps.am.audio.Synchronizer;
import	org.jsresources.apps.am.audio.AMMsgFileTool;
import	org.jsresources.apps.am.audio.AMAudioFormat;
import	org.jsresources.apps.am.audio.AudioCapture;
import	org.jsresources.apps.am.audio.AMAppletWorkaround;
import	org.jsresources.apps.am.util.AMUtil;
import	org.jsresources.apps.am.net.BufferedSocketOutputStream;

import	java.io.IOException;
import	java.io.InputStream;
import	java.io.OutputStream;
import	java.io.ByteArrayOutputStream;
import	java.net.Socket;
import	java.net.URL;
import	javax.sound.sampled.*;

public class CallerClient {

	private URL m_url;
	private String m_callerName;

	private AudioInputStream m_audioInputStream=null;
	private AudioCapture m_audio=null;
	private BufferedSocketOutputStream m_sockOut=null;
	private Synchronizer m_sync=null;
	private int m_formatCode=1;

	public CallerClient(URL url) {
		if (Debug.TRACE) {
			Debug.println("CallerClient("+url+")");
		}
		m_url=url;
	}

	public void open(String callerName, int formatCode) throws Exception {
		m_callerName=callerName;
		m_formatCode=formatCode;
		if (Debug.TRACE) {
			Debug.println("CallerClient.open(): Preparing audio input...");
		}
		m_audio = new AudioCapture(formatCode);
		m_audio.open();
		m_audioInputStream = m_audio.getAudioInputStream();

		// add here for a format conversion
		// for applets need to do the workaround
		//m_audioInputStream = AudioSystem.getAudioInputStream(AMAudioFormat.getNetAudioFormat(formatCode), m_audioInputStream);
		m_audioInputStream = AMAppletWorkaround.getAudioInputStream(AMAudioFormat.getNetAudioFormat(formatCode), m_audioInputStream);
		
		if (Debug.TRACE) {
			Debug.println("CallerClient.open(): Preparing net output...");
		}
		m_sockOut = new BufferedSocketOutputStream();
		m_sockOut.open(m_url);
		if (Debug.TRACE) {
			Debug.println("CallerClient.open(): end");
		}
	}

	public void writeHeader(OutputStream stream, AudioFormat format) throws Exception {
		if (Debug.TRACE) {
			Debug.println("CallerClient.writeHeader(): Writing header...");
		}
		ByteArrayOutputStream baos=new ByteArrayOutputStream(AMMsgFileTool.getHeaderSize(m_callerName));
		AMMsgFileTool.writeHeader(baos, format, m_callerName);
		stream.write(baos.toByteArray());
	}

	public void start() throws Exception {
		if (Debug.TRACE) {
			Debug.println("CallerClient.start(): begin");
		}
		if (m_audio==null || m_sockOut==null || m_audioInputStream==null) {
			throw new Exception("open() must be called before start!");
		}
		writeHeader(m_sockOut, m_audioInputStream.getFormat());
		if (Debug.TRACE) {
			Debug.println("CallerClient.start(): Preparing synchronizer...");
		}
		// 150ms buffer size for synchronizer
		m_sync=new Synchronizer(m_audioInputStream, m_sockOut, (int) AMAudioFormat.ms2Bytes(150, m_audioInputStream.getFormat()));
		if (Debug.TRACE) {
			Debug.println("CallerClient.start(): Starting audio...");
		}
		m_audio.start();
		if (Debug.TRACE) {
			Debug.println("CallerClient.start(): Starting net...");
		}
		m_sockOut.start();
		if (Debug.TRACE) {
			Debug.println("CallerClient.start(): Starting Synchronizer...");
		}
		m_sync.start();
		if (Debug.TRACE) {
			Debug.println("CallerClient.start(): end");
		}
	}

	public void close(boolean immediate) throws Exception {
		if (Debug.TRACE) {
			Debug.println("CallerClient.close(): begin");
		}
		String error="";
		if (m_sync!=null) {
			if (Debug.DEBUG) {
				Debug.println("CallerClient.close(): Stopping Synchronizer "+(immediate?"":"not ")+"immediate");
			}
			try {
				m_sync.stop(immediate);
			} catch (Exception e1) {
				error+="   "+e1.getMessage();
			}
			//m_sync=null;
		}

		if (m_sockOut!=null) {
			if (Debug.DEBUG) {
				Debug.println("CallerClient.close(): Stopping and wait for Socket "+(immediate?"":"not ")+"immediate");
			}
			try {
				m_sockOut.stop(immediate, immediate);
			} catch (Exception e2) {
				error+="   "+e2.getMessage();
			}
			//m_sockOut=null;
		}

		if (m_audio!=null) {
			// shouldn't be necessary. But if everything goes wrong, we want at least
			// close the soundcard...
			try {
				m_audio.close();
			} catch (Exception e3) {
				error+="   "+e3.getMessage();
			}
			m_audio=null;
		}
		m_audioInputStream=null;
		if (error!="") {
			throw new Exception(error);
		}
		if (Debug.TRACE) {
			Debug.println("CallerClient.close(): end");
		}
	}

	public long getLineMs() {
		if (m_sync==null) {
			return -1;
		} else {
			return AMAudioFormat.netBytes2Ms(m_sync.getReadPos(), m_formatCode);
		}
	}

	public long getBufferMs() {
		if (m_sockOut==null) {
			return -1;
		} else {
			return AMAudioFormat.netBytes2Ms(m_sockOut.getBufferSize(), m_formatCode);
		}
	}

	public long getNetMs() {
		if (m_sockOut==null) {
			return -1;
		} else {
			return AMAudioFormat.netBytes2Ms(m_sockOut.getPos(), m_formatCode);
		}
	}

	public long getTimeMs() {
		if (m_audio==null) {
			return -1;
		} else {
			return m_audio.getTime();
		}
	}

	public boolean isRecording() {
		return m_sync!=null && m_sync.isRunning();
	}

	public boolean isSending() {
		return m_sockOut!=null && m_sockOut.isRunning();
	}

}

/*** CallerClient.java ***/
