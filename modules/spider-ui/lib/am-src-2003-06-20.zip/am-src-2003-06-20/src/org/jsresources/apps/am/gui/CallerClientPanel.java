/*
 *	CallerClientPanel.java
 *
 *	GUI for sending recorded audio to a server
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package org.jsresources.apps.am.gui;

import	org.jsresources.apps.am.util.AMTimer;
import	org.jsresources.apps.am.CallerClient;
import	org.jsresources.apps.am.Debug;
import	org.jsresources.apps.am.audio.AMAudioFormat;

import	java.awt.BorderLayout;
import	java.awt.FlowLayout;
import	java.awt.GridLayout;
import	java.awt.Font;
import	java.awt.event.ActionEvent;
import	java.awt.event.ActionListener;
import	java.net.URL;

import	javax.swing.JSeparator;

import	javax.swing.JButton;
import	javax.swing.SwingConstants;
import	javax.swing.JLabel;
import	javax.swing.JPanel;
import	javax.swing.JTextField;
import	javax.swing.JOptionPane;
import	javax.swing.JComboBox;

/*
 Matthias and Florians answering machine
 ----
 1. Enter your name
 2. Press Start
 3. Record your message
 4. Press Stop
 5. Wait until all data has been transferred (Net)
 -----
 your name: _____________
 ----
 Quality drop-down box (13.2KBit/s GSM, 64KBit/s Tel, 705.6KBit/s CD)
 ---
                Audio:  _____ 
 Start  Stop    Buffer: _____
                Net:    _____ 
 Status
*/

public class CallerClientPanel extends AMPanel implements AMTimer.Listener {

	private JLabel		m_audio;
	private JLabel		m_queue;
	private JLabel		m_net;
	private JButton		m_startButton;
	private JButton		m_stopButton;
	private JTextField	m_nameField;
	private JComboBox	m_qualitySelector;


	private CallerClient	m_client=null;
	private AMTimer	m_displayThread=null;

	private final static int STATE_NONE=0;
	private final static int STATE_RECORDING=1;
	private final static int STATE_SENDING=2;
	private int m_state=STATE_NONE;

	public CallerClientPanel(String title, URL url) {
		super(title, url);
		setLayout(new StripeLayout(4));
		add(m_titleLabel);
		add(new JSeparator());

		add(new JLabel("1. Enter your name"));
		add(new JLabel("2. Press Start"));
		add(new JLabel("3. Record your message"));
		add(new JLabel("4. Press Stop"));
		add(new JLabel("5. Wait until all data has been transferred"));
		add(new JSeparator());

		JPanel panel=new JPanel();
		panel.setLayout(new BorderLayout());
		panel.add("West", new JLabel("Your name:"));
		m_nameField=new JTextField();
		panel.add("Center", m_nameField);
		add(panel);
		
		m_qualitySelector=new JComboBox(AMAudioFormat.FORMAT_NAMES);
		add(m_qualitySelector);

		JPanel panel1=new JPanel();
		panel1.setLayout(new FlowLayout());
		m_startButton=new JButton("Start");
		m_startButton.addActionListener(new ActionListener() {
			                                public void actionPerformed(ActionEvent ae) {
				                                startRec();
			                                }});
		panel1.add(m_startButton);
		m_stopButton=new JButton("Stop");
		m_stopButton.addActionListener(new ActionListener() {
			                               public void actionPerformed(ActionEvent ae) {
				                               stopRec();
			                               }});
		m_stopButton.setEnabled(false);
		panel1.add(m_stopButton);

		JPanel panel2=new JPanel();
		panel2.setLayout(new GridLayout(3,2));
		JLabel label=new JLabel("Recorded: ");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		panel2.add(label);
		m_audio=new JLabel("(none)");
		panel2.add(m_audio);
		label=new JLabel("Buffer: ");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		panel2.add(label);
		m_queue=new JLabel("(none)");
		panel2.add(m_queue);
		label=new JLabel("Network: ");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		panel2.add(label);
		m_net=new JLabel("(none)");
		panel2.add(m_net);

		panel=new JPanel();
		panel.setLayout(new BorderLayout());
		panel.add("West", panel1);
		panel.add("Center", panel2);
		add(panel);
		add(new JSeparator());

		add(m_status);
	}

	private void startRec()	{
		close();
		setStartButtonEnabled(false);
		setStopButtonEnabled(false);
		try {
			beginWait();
			try {
				m_state=STATE_NONE;
				m_displayThread=new AMTimer(this);
				m_displayThread.start();
				m_client=new CallerClient(getURL());
				m_client.open(m_nameField.getText(), 
				AMAudioFormat.FORMAT_CODES[m_qualitySelector.getSelectedIndex()]);
				m_client.start();
			} finally {
				endWait();
			}
		} catch (Throwable t) {
			handleException(t);
			m_startButton.setEnabled(true);
			close();
			onTimer();
		}
	}


	private void stopRec() {
		try {
			if (m_client!=null) {
				m_client.close(false);
			}
		} catch (Throwable t) {
			handleException(t);
			m_startButton.setEnabled(true);
		}
	}

	private synchronized void setStopButtonEnabled(boolean enable) {
		m_stopButton.setEnabled(enable);
	}

	private synchronized void setStartButtonEnabled(boolean enable) {
		m_startButton.setEnabled(enable);
	}

	public synchronized boolean onTimer() {
		boolean result=true;
		String atext="(none)";
		String btext="(none)";
		String ntext="(none)";
		int newState=STATE_NONE;
		if (m_client!=null) {
			if (m_client.isRecording()) {
				newState=STATE_RECORDING;
			} else if (m_client.isSending()) {
				newState=STATE_SENDING;
			}
		}
		if (m_client!=null) {
			if (newState!=STATE_RECORDING) {
				atext=niceTime(m_client.getLineMs());
			} else {
				atext=niceTime(m_client.getTimeMs());
			}
			btext=niceTime(m_client.getBufferMs());
			ntext=niceTime(m_client.getNetMs());
		}
		m_audio.setText(atext);
		m_queue.setText(btext);
		m_net.setText(ntext);
		if (newState!=m_state) {
			if (m_state!=STATE_NONE && newState==STATE_NONE) {
				// transition to stop
				status("Recorded and sent "+niceTime(m_client.getNetMs())+" successfully.");
				setStopButtonEnabled(false);
				setStartButtonEnabled(true);
				result=false;
			} else if (m_state!=STATE_RECORDING && newState==STATE_RECORDING) {
				setStopButtonEnabled(true);
				status("Recording...");
			} else if (m_state!=STATE_SENDING && newState==STATE_SENDING) {
				setStopButtonEnabled(false);
				status("Flushing buffers...");
			}
			m_state=newState;
		}
		return result;
	}

	public void destroyImpl() {
		close();
	}
	
	public synchronized void close() {
		try {
			if (m_displayThread!=null) {
				m_displayThread.terminate();
			}
			if (m_client!=null) {
				m_client.close(true);
				m_client=null;
			}
		} catch (Throwable t) {
			handleException(t);
		}
	}
}

/*** CallerClientPanel.java ***/
