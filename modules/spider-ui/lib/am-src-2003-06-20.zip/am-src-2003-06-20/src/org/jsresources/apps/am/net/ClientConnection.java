/*
 *	ClientConnection.java
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

/*
   Connection to a server. Currently, there are 3 diffrent clients:
   AMClientConnection: connects to a dedicated server in class 
      org.jsresources.apps.am.Server
   HttpClientConnection: connects to an http server using 
      java.net.HttpURLConnection. Requests are sent like this:
      "list", "remove" and "get" commands are sent as GET method
      to the server, with the command and eventual parameters as
      query string to the URL. The "put" command uses the http PUT 
      method and does not provide a query string.
   AMHttpClientConnection: Like HttpClientConnection, but it uses
      a self-written http client to overcome buffering done in
      java.net.HttpURLConnection (which prevents simultaneous
      recording/playing and network activity).
   
   Commands:
   
   "list"
 
   The server replies by sending a list of the messages. There is one line
   (terminated by an EOL character for each message. At the end, there is
   an additional empty line to signal the end of the list. The line of a
   message consists of an id, followed by 3 integer numbers that are coded 
   in decimal ASCII representation follwed by a descriptive text. 
   1. ID: an opaque string that serves as identifier for this message
   2. Size: This number is the length of the message in bytes.
   3. Date: This number is the arrival date of the message, represented in
      milliseconds since January 1st, 1970. 
   4. Format: This number is the format code of the message. Format codes 
      are defined in org.jsresources.apps.am.audio.AMAudioFormat.
   5. Name: The following text is a textual representation gathered from 
      the file. It is used as caller name.
   To get informed of new incoming messages, the client has to issue a new 
   "list" command. 
   There is no guarantee that messages appear at the same position in the 
   list between subsequent "list" commands (this may depend on the server's 
   file system implementation).
 
   "get <message id> [<start offset>]"
 
   The server responds by sending the data on the message in binary
   representation, as it is stored in the file system. 
   
   The message id is a hash calculated from message raw date and file size.
   Use AMUtil.getMessageID() to get the id.
   The first line in the
   list belongs to the message number 0. You can use the "get" command even
   without issuing "list" before. However, you won't know which message you
   get. "get" with an invalid message number is simply ignored. The binary
   data sent by the server do not have a special signaling of end. The server
   just stops sending data. The client has to remember the message length
   as passed in the response to the "list" command and detect the end on its
   own. Message numbers are invalidated by a "remove" command. After a
   "remove", the client has to fetch the list again.
   The optional start offset indicates that file serving should start at the
   specified byte offset in the file.
 
   "remove <message id>"
 
   The server removes the message by deleting the file that held the message
   from the file system. In other words, there is no way of recovering a
   removed message. The message id is as explained in the section on
   the "get" command. After a "remove", the list is invalidated. The client
   has to re-fetch the list before the next "get" or "remove".
   
   "put"
   
   After this line has been submitted, the server expects the message to be sent
   over the same socket connection. The connection has to be closed to mark the
   end of data. It will be saved as a file in the messages directory.
*/

package org.jsresources.apps.am.net;

import	org.jsresources.apps.am.Debug;
import	java.io.IOException;
import	java.io.InputStream;
import	java.io.OutputStream;
import	java.net.URL;

public abstract class ClientConnection implements NetConstants {
	protected InputStream m_inStream;
	protected OutputStream m_outStream;
	protected URL m_url;
	protected boolean m_doOutput;

	protected ClientConnection(URL url) {
		if (Debug.TRACE) {
			Debug.println("ClientConnection(): <init> on URL \""+url+"\"");
		}
		m_url=url;
	}
	
	protected boolean isPutCommand(String command) {
		return command.startsWith("put") || command.startsWith("PUT");
	}
	
	public static ClientConnection getClientConnection(URL url) throws IOException {
		if (CLIENT_USE==USE_OWN_SERVER) {
			return new AMClientConnection(url);
		}
		else if (CLIENT_USE==USE_HTTP) {
			return new HttpClientConnection(url);
		}
		else if (CLIENT_USE==USE_OWN_HTTP) {
			return new AMHttpClientConnection(url);
		}
		throw new IOException("Client choice not set in AMConstants");
	}

	protected abstract void sendCommandImpl(String command, String params) throws IOException;
	
	public void sendCommand(String command) throws IOException {
		sendCommand(command, "");
	}

	public void sendCommand(String command, String params) throws IOException {
		if (Debug.TRACE) {
			Debug.println(getClass().getName()+".sendCommand(\""+command+"\", \""+params+"\")");
		}
		command=command.toUpperCase();
		m_doOutput=isPutCommand(command);
		try {
			sendCommandImpl(command, params);
		} catch (IOException ioe) {
			close();
			throw ioe;
		}
	}

	public int read(byte[] buffer) throws IOException {
		return getInputStream().read(buffer);
	}

	public InputStream getInputStream() throws IOException {
		return m_inStream;
	}

	public OutputStream getOutputStream() throws IOException {
		if (!m_doOutput) {
			throw new IOException("Requesting OutputStream on an only-input connection !");
		}
		return m_outStream;
	}

	public int getSendBufferSize() {
		return 2048;
	}

	public void close() {
		if (m_inStream!=null) {
			if (Debug.TRACE) {
				Debug.println(getClass().getName()+".close(): closing inStream");
			}
			try {
				m_inStream.close();
			} catch (IOException ioe1) {}
			m_inStream=null;
		}
		if (m_outStream!=null) {
			try {
				if (Debug.TRACE) {
					Debug.println(getClass().getName()+".close(): closing outStream");
				}
				m_outStream.close();
			} catch (IOException ioe2) {}
			m_outStream=null;
		}
		if (Debug.TRACE) {
			Debug.println(getClass().getName()+".close(): finished");
		}
	}
	
	// the following 2 methods should actually be in an intermediate class
	// between this and HttpClientConnection or AMHttpClientConnection...
	protected URL getHttpURL(String params) throws IOException {
		if (params=="") {
			return m_url;
		}
		// make query string
		StringBuffer sb=new StringBuffer(params);
		for (int i=0; i<sb.length(); i++) {
			if (sb.charAt(i)==' ') {
				sb.setCharAt(i, '&');
			}
		}
		return new URL(m_url.getProtocol(), 
			m_url.getHost(), 
			m_url.getPort(), 
			m_url.getPath()+"?"+sb.toString());
	}
}

/*** ClientConnection.java ***/
