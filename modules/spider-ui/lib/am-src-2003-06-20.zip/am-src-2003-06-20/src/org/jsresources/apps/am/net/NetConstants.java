/*
 *	NetConstants.java
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package org.jsresources.apps.am.net;

public interface NetConstants {
	/** Use our own server (Server.java) */
	public static final int USE_OWN_SERVER=0;
	/** Use URLCOnnection to connect to a web server */
	public static final int USE_HTTP=1;
	/** Use our own HTTP client to connect to a web server */
	public static final int USE_OWN_HTTP=2;
	
	/** chooses which server/client to use */
	public static final int CLIENT_USE=USE_OWN_HTTP;
	//public static final int CLIENT_USE=USE_HTTP;
	//public static final int CLIENT_USE=USE_OWN_SERVER;
	
	public static final String USER_AGENT="AM/1.0 (Bomers/Pfisterer; http://www.jsresources.org)";
	
	public static final String DEFAULT_SERVER_PROTOCOL="http";
	public static final int DEFAULT_SERVER_PORT=2342;
	public static final String DEFAULT_SERVER=DEFAULT_SERVER_PROTOCOL+"://localhost:"+DEFAULT_SERVER_PORT;
	
	public static int NET_TIMEOUT=10000; // in ms
	
}

/*** NetConstants.java ***/

