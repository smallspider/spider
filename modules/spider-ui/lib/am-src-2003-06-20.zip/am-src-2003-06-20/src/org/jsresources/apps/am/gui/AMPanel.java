/*
 *	AMPanel.java
 *
 *	Base class for panels of the AM
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package org.jsresources.apps.am.gui;

import	org.jsresources.apps.am.Debug;
import	org.jsresources.apps.am.net.NetConstants;

import	java.awt.Font;
import	java.awt.Cursor;
import	java.awt.Rectangle;
import	java.net.URL;

import	javax.swing.SwingConstants;
import	javax.swing.JComponent;
import	javax.swing.JLabel;
import	javax.swing.JOptionPane;
import	javax.swing.JPanel;


public abstract class AMPanel extends JPanel {

	protected JLabel m_titleLabel;
	protected JLabel m_status;
	private URL m_url;
	private boolean m_statusChanged=false;
	private boolean m_destroyed=false;

	public AMPanel(String title, URL url) {
		super();
		m_url=url;

		m_titleLabel=new JLabel(title);
		Font font=m_titleLabel.getFont();
		if (font!=null) {
			m_titleLabel.setFont(font.deriveFont(Font.BOLD, font.getSize()*2));
		}
		m_titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		m_status=new JLabel("Ready");
		m_status.setOpaque(true);
	}
	
	protected void dispatchEvent(int id) {
		dispatchEvent(new AMEvent(this, id));
	}
	
	// paints a component directly
	protected void paintImmediately(JComponent comp) {
		// the following methods do not work !!
		//comp.paint(comp.getGraphics());
		//comp.paintImmediately(comp.getBounds(new Rectangle()));
		//comp.invalidate();
		//comp.repaint();
		comp.update(comp.getGraphics()); // component needs to be opaque...
	}

	protected synchronized void status(String text) {
		status(text, false);
	}

	protected synchronized void status(String text, boolean immediately) {
		if (text==null || text.length()==0) {
			text="Ready";
		}
		m_status.setText(text);
		if (immediately) {
			paintImmediately(m_status);
		}
		m_statusChanged=true;
	}

	protected void handleException(Throwable t) {
		String s=t.getMessage();
		if (s==null || s=="") {
			s=t.toString();
		}
		if (Debug.SHOW_ALL_EXCEPTIONS) {
			t.printStackTrace();
		}
		if (!isDestroyed()) {
			JOptionPane.showMessageDialog(null, s);
			status(s);
		}
	}

	protected URL getURL() {
		return m_url;
	}


	protected String niceTime(long ms) {
		if (ms>=0) {
			return ""+(ms/1000)+"."+((ms % 1000)/100)+"s";
		} else {
			return "(none)";
		}
	}
	
	protected void statusBeginConnecting() {
		String dest=m_url.toString();
		if (NetConstants.CLIENT_USE==NetConstants.USE_OWN_SERVER) {
			dest=m_url.getHost()+":"+m_url.getPort();
		}
		status("Connecting to "+dest+"...", true);
	}
	
	protected void beginWait() {
		setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
	}

	protected void endWait() {
		setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	}
	
	protected boolean isDestroyed() {
		return m_destroyed;
	}
	
	public abstract void destroyImpl();
	
	public void destroy() {
		m_destroyed=true;
		destroyImpl();
	}

	// is called after the window is shown
	public void afterShow() {
		// try to get tritonus_gsm and tritonus_share
		// this is not strictly necessary, but
		// nicer, as the jars are loaded at initialization time
		try {
			Class.forName("org.tritonus.sampled.convert.gsm.GSMFormatConversionProvider");
			Class.forName("org.tritonus.share.sampled.Encodings");
		} catch (ClassNotFoundException cnfe) {
			handleException(new Exception("tritonus_share.jar or tritonus_gsm.jar not properly installed !"));
		}
	}
}

/*** AMPanel.java ***/
