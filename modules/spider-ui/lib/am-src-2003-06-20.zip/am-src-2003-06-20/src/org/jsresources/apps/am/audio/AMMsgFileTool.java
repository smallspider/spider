/*
 *	AMMsgFileTool.java
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package org.jsresources.apps.am.audio;

import	javax.sound.sampled.*;
import	java.io.*;

public class AMMsgFileTool {

	public static final int	HEADER_MAGIC = 0x464D3031; // "FM01"
	public static final int	MAX_DESCRIPTION_LENGTH = 300;
	
	private static String readDescription(DataInputStream dis, int len) throws IOException {
		byte c=-1;
		String ret="";
		while (len>0 && (c=dis.readByte())!=0) {
			ret=ret+(char) c;
			len--;
		}
		if (len>1 && c==0) {
			dis.skip(len-1);
		}
		return ret;
	}

	public static AudioFormat readHeader(InputStream inputStream) throws UnsupportedAudioFileException, IOException {
		DataInputStream	dataInputStream = new DataInputStream(inputStream);
		int nFormat = 0;
		String desc="";
		try {
			nFormat = readFormatCode(dataInputStream);
			desc=readDescription(dataInputStream);
		} catch (IOException ioe) {
			throw ioe;
		} catch (Exception e) {
			throw new UnsupportedAudioFileException(e.getMessage());
		}
		AudioFormat format = AMAudioFormat.getNetAudioFormat(nFormat);
		return format;
	}

	private static String readDescription(DataInputStream dataInputStream) throws Exception, IOException {
		int descLen = dataInputStream.readInt();
		if (descLen < 0 || descLen>MAX_DESCRIPTION_LENGTH) {
			throw new Exception("not an AM Message file: length of description must be positive");
		}
		String desc=readDescription(dataInputStream, descLen);
		return desc;
	}

	private static int readFormatCode(DataInputStream dataInputStream) throws Exception, IOException {
		int	magic = dataInputStream.readInt();
		if (magic != HEADER_MAGIC) {
			throw new Exception("not an AM Message file: wrong header magic");
		}
		int nFormat = dataInputStream.readInt();
		return nFormat;
	}

	public static String getDescription(File file) throws Exception, IOException {
		DataInputStream	fileIn = new DataInputStream(new FileInputStream(file));
		String ret="";
		try {
			readFormatCode(fileIn);
			ret=readDescription(fileIn);
		}
		finally {
			fileIn.close();
		}
		return ret;
	}

	public static int getFormatCode(File file) throws Exception, IOException {
		DataInputStream	fileIn = new DataInputStream(new FileInputStream(file));
		int ret=0;
		try {
			ret=readFormatCode(fileIn);
		}
		finally {
			fileIn.close();
		}
		return ret;
	}

	/**
	* Writes a null-terminated ascii string s to f.
	* The total number of bytes written is aligned on a 2byte boundary.
	* @exception IOException Write error.
	*/
	protected static void writeText(DataOutputStream dos, String s) throws IOException {
		if (s.length()>0) {
			dos.writeBytes(s);
			dos.writeByte(0);  // pour terminer le texte
			if ((s.length() % 2)==0) {
				// ajout d'un zero pour faire la longeur pair
				dos.writeByte(0);
			}
		}
	}

	/**
	* Returns number of bytes that have to written for string s (with alignment)
	*/
	protected static int getTextLength(String s) {
		if (s.length()==0) {
			return 0;
		} else {
			return (s.length()+2) & 0xFFFFFFFE;
		}
	}

	// modified from AuAudioOutputStream
	public static void writeHeader(OutputStream os, AudioFormat format, String description) throws IOException {
		DataOutputStream dos=new DataOutputStream(os);
		dos.writeInt(HEADER_MAGIC);
		dos.writeInt(AMAudioFormat.getFormatCode(format));
		dos.writeInt(getTextLength(description));
		writeText(dos, description);
	}

	public static int getHeaderSize(String description) {
		return 12+getTextLength(description);
	}
}

/*** AMMsgFileTool.java ***/

