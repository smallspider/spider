/*
 *	AMAppletWorkaround.java
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package org.jsresources.apps.am.audio;

import	org.jsresources.apps.am.Debug;
import	javax.sound.sampled.AudioFormat;
import	javax.sound.sampled.AudioSystem;
import	javax.sound.sampled.AudioInputStream;

/**
 *	From JRE/JDK 1.3.0_01 on, applets can not use provided service
 *	providers. Obviously, in these later releases of the Java 2 platform
 *	the service providers are only searched on the system/boot classloader
 *	and NOT on the classloader of the applet.
 *	Our GSM encoder/decoder is a service provider for Java Sound. When
 *	the applet tries to encode/decode GSM audio data, AudioSystem does not
 *	find the service provider and an exception is thrown.
 *	This class presents an ugly workaround for that problem: first, we
 *	try to use AudioSystem.getAudioInputStream to use the normal
 *	service provider lookup mechanism. If that fails, we just try
 *	the GSM service provider directly.
 */

public class AMAppletWorkaround {
	
	public static AudioInputStream getAudioInputStream(AudioFormat targetFormat, 
			AudioInputStream sourceStream) {
		try {
			return AudioSystem.getAudioInputStream(targetFormat, sourceStream);
		} catch (IllegalArgumentException iae) {
			// now just try the GSM conversion provider...
			// this may also throw an exception
			if (Debug.DEBUG) {
				Debug.println("Using AMAppletWorkaround to get GSM codec");
			}
			try {
				Class.forName("org.tritonus.sampled.convert.gsm.GSMFormatConversionProvider");
				return new org.tritonus.sampled.convert.gsm.GSMFormatConversionProvider().getAudioInputStream(
					targetFormat,sourceStream);
			} catch (ClassNotFoundException cnfe) {
				throw new IllegalArgumentException("GSM codec not properly installed !");
			}
		}
	}
}

/*** AMAppletWorkaround.java ***/
