/*
 *	BufferQueueStream.java
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package org.jsresources.apps.am.audio;

import	org.jsresources.apps.am.Debug;
import	org.jsresources.apps.am.util.BufferQueue;

public class BufferQueueStream extends BufferQueue {

	private int currBuffReadPos=0;
	private int currBuffReadNumber=0;
	private long currReadPos=0;

	public BufferQueueStream() {
		super(true);
	}

	public synchronized byte[] removeBuffer() {
		byte[] result=super.removeBuffer();
		if (currReadPos>availableBytes()) {
			currReadPos=availableBytes();
			currBuffReadPos=0;
			currBuffReadNumber=availableBuffers();
		}
		return result;
	}

	public synchronized int read(byte[] buffer, int pos, int len) {
		int res=0;
		while (res<len && currBuffReadNumber<availableBuffers()) {
			byte[] thisBuffer=getBuffer(currBuffReadNumber);
			int toRead=thisBuffer.length-currBuffReadPos;
			if (toRead+res>len) {
				toRead=len-res;
			}
			System.arraycopy(thisBuffer, currBuffReadPos, buffer, pos, toRead);
			pos+=toRead;
			currReadPos+=toRead;
			currBuffReadPos+=toRead;
			res+=toRead;
			if (currBuffReadPos>=thisBuffer.length) {
				currBuffReadNumber++;
				currBuffReadPos=0;
			}
		}
		if (Debug.TRACE_READWRITE) {
			Debug.println("BufferQueueStream.read: read "+res+" bytes from buffer");
		}
		return res;
	}

	public synchronized void clear() {
		super.clear();
		currBuffReadPos=0;
		currBuffReadNumber=0;
		currReadPos=0;
	}

	public synchronized long availableRead() {
		return availableBytes()-currReadPos;
	}

	public synchronized long getPos() {
		return currReadPos;
	}

	public synchronized long setPos(long pos) {
		if (Debug.TRACE) {
			Debug.println("BufferQueueStream.setPos("+pos+")");
		}
		if (pos>=availableBytes()) {
			currBuffReadPos=0;
			currBuffReadNumber=availableBuffers();
			currReadPos=availableBytes();
		} else {
			if (pos<currReadPos) {
				currBuffReadNumber=0;
				currReadPos=0;
			} else {
				currReadPos-=currBuffReadPos;
			}
			while (true) {
				byte[] thisBuffer=getBuffer(currBuffReadNumber);
				if (thisBuffer.length+currReadPos>pos) {
					currBuffReadPos=(int) (pos-currReadPos);
					break;
				}
				currBuffReadNumber++;
				currReadPos+=thisBuffer.length;
			}
			currReadPos=pos;
		}
		return currReadPos;
	}

} // BufferQueueStream


