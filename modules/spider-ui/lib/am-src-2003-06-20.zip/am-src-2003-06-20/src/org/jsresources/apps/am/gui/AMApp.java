/*
 *	AMApp.java
 *
 */

/*
 *  Copyright (c) 2001 by Florian Bomers <florian@bome.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU Library General Public License as published
 *   by the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Library General Public License for more details.
 *
 *   You should have received a copy of the GNU Library General Public
 *   License along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package org.jsresources.apps.am.gui;

import	org.jsresources.apps.am.gui.AMPanel;
import	org.jsresources.apps.am.net.NetConstants;
import	java.awt.event.WindowEvent;
import	java.awt.event.WindowAdapter;
import	java.net.URL;
import	javax.swing.JFrame;

public abstract class AMApp extends JFrame implements NetConstants {
	private AMPanel m_client;

	public AMApp(String[] args) {
		super("Answering machine");
		String sUrl=DEFAULT_SERVER;
		if (args.length>0) {
			sUrl=args[0];
		}
		URL url=null;
		try {
			url=new URL(sUrl);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
		this.addWindowListener(new WindowAdapter() {
			                       public void windowClosing(WindowEvent we) {
				                       if (m_client!=null) {
					                       m_client.destroy();
				                       }
				                       System.exit(0);
			                       }
		                       }
		                      );
		m_client = createClientPanel(url);
		this.getContentPane().add(m_client);
		pack();
		show();
		afterShow();
	}

	public abstract AMPanel createClientPanel(URL url);

	public void afterShow() {
		if (m_client!=null) {
			m_client.afterShow();
		}
	}
}

/*** AMApp.java ***/
